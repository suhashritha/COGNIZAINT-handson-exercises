-- ============================================================
-- PL/SQL PROGRAMMING - EXERCISE 1: CONTROL STRUCTURES
-- DN5 Solutions
-- ============================================================

-- ============================================================
-- DATABASE SCHEMA CREATION
-- ============================================================

-- Create Customers Table
CREATE TABLE Customers (
    CustomerID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    DOB DATE,
    Balance NUMBER,
    LastModified DATE,
    IsVIP VARCHAR2(5) DEFAULT 'FALSE'
);

-- Create Accounts Table
CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    AccountType VARCHAR2(20),
    Balance NUMBER,
    LastModified DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create Transactions Table
CREATE TABLE Transactions (
    TransactionID NUMBER PRIMARY KEY,
    AccountID NUMBER,
    TransactionDate DATE,
    Amount NUMBER,
    TransactionType VARCHAR2(10),
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

-- Create Loans Table
CREATE TABLE Loans (
    LoanID NUMBER PRIMARY KEY,
    CustomerID NUMBER,
    LoanAmount NUMBER,
    InterestRate NUMBER,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create Employees Table
CREATE TABLE Employees (
    EmployeeID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Position VARCHAR2(50),
    Salary NUMBER,
    Department VARCHAR2(50),
    HireDate DATE
);

-- ============================================================
-- SAMPLE DATA INSERTION
-- ============================================================

-- Insert sample customers with various ages
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (1, 'John Doe', TO_DATE('1985-05-15', 'YYYY-MM-DD'), 5000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (2, 'Jane Smith', TO_DATE('1960-07-20', 'YYYY-MM-DD'), 15000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (3, 'Robert Wilson', TO_DATE('1955-03-10', 'YYYY-MM-DD'), 8000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (4, 'Emily Davis', TO_DATE('1992-11-25', 'YYYY-MM-DD'), 12000, SYSDATE);

INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
VALUES (5, 'Michael Brown', TO_DATE('1958-08-05', 'YYYY-MM-DD'), 3000, SYSDATE);

-- Insert sample loans
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 50000, 7.5, SYSDATE - 365, SYSDATE + 10);

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (2, 2, 100000, 8.0, SYSDATE - 730, SYSDATE + 15);

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (3, 3, 75000, 7.0, SYSDATE - 180, SYSDATE + 45);

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (4, 4, 25000, 6.5, SYSDATE - 90, SYSDATE + 60);

INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (5, 5, 40000, 7.25, SYSDATE - 400, SYSDATE + 25);

COMMIT;

-- ============================================================
-- SCENARIO 1: Apply Discount to Senior Citizens (Age > 60)
-- Apply 1% discount to loan interest rates for customers above 60
-- ============================================================

DECLARE
    -- Cursor to fetch all customers with their loans
    CURSOR c_senior_customers IS
        SELECT c.CustomerID, c.Name, 
               TRUNC(MONTHS_BETWEEN(SYSDATE, c.DOB) / 12) AS Age,
               l.LoanID, l.InterestRate
        FROM Customers c
        JOIN Loans l ON c.CustomerID = l.CustomerID
        WHERE TRUNC(MONTHS_BETWEEN(SYSDATE, c.DOB) / 12) > 60;
    
    v_customer_id   Customers.CustomerID%TYPE;
    v_customer_name Customers.Name%TYPE;
    v_customer_age  NUMBER;
    v_loan_id       Loans.LoanID%TYPE;
    v_interest_rate Loans.InterestRate%TYPE;
    v_new_rate      NUMBER;
    v_discount      CONSTANT NUMBER := 1; -- 1% discount
    v_count         NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('SCENARIO 1: SENIOR CITIZEN LOAN DISCOUNT');
    DBMS_OUTPUT.PUT_LINE('Applying 1% discount to customers over 60 years');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    FOR rec IN c_senior_customers LOOP
        -- Calculate new interest rate
        v_new_rate := rec.InterestRate - v_discount;
        
        -- Update the loan interest rate
        UPDATE Loans
        SET InterestRate = v_new_rate
        WHERE LoanID = rec.LoanID;
        
        -- Output the change
        DBMS_OUTPUT.PUT_LINE('Customer: ' || rec.Name || ' (Age: ' || rec.Age || ')');
        DBMS_OUTPUT.PUT_LINE('  Loan ID: ' || rec.LoanID);
        DBMS_OUTPUT.PUT_LINE('  Old Interest Rate: ' || rec.InterestRate || '%');
        DBMS_OUTPUT.PUT_LINE('  New Interest Rate: ' || v_new_rate || '%');
        DBMS_OUTPUT.PUT_LINE('  Discount Applied: ' || v_discount || '%');
        DBMS_OUTPUT.PUT_LINE('');
        
        v_count := v_count + 1;
    END LOOP;
    
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No customers above 60 years with active loans found.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Total loans updated: ' || v_count);
    END IF;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;
/

-- ============================================================
-- SCENARIO 2: Set VIP Status for High Balance Customers
-- Set IsVIP to TRUE for customers with balance over $10,000
-- ============================================================

DECLARE
    -- Cursor to iterate through all customers
    CURSOR c_all_customers IS
        SELECT CustomerID, Name, Balance
        FROM Customers
        FOR UPDATE OF IsVIP;
    
    v_vip_threshold CONSTANT NUMBER := 10000;
    v_vip_count     NUMBER := 0;
    v_total_count   NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('SCENARIO 2: VIP STATUS UPDATE');
    DBMS_OUTPUT.PUT_LINE('Setting VIP status for balances over $' || v_vip_threshold);
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    FOR rec IN c_all_customers LOOP
        v_total_count := v_total_count + 1;
        
        -- Check if balance exceeds threshold
        IF rec.Balance > v_vip_threshold THEN
            -- Update VIP status
            UPDATE Customers
            SET IsVIP = 'TRUE'
            WHERE CURRENT OF c_all_customers;
            
            DBMS_OUTPUT.PUT_LINE('✓ ' || rec.Name || ' - Balance: $' || 
                                 TO_CHAR(rec.Balance, '999,999.99') || ' -> VIP STATUS GRANTED');
            v_vip_count := v_vip_count + 1;
        ELSE
            DBMS_OUTPUT.PUT_LINE('✗ ' || rec.Name || ' - Balance: $' || 
                                 TO_CHAR(rec.Balance, '999,999.99') || ' -> Not eligible for VIP');
        END IF;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Summary:');
    DBMS_OUTPUT.PUT_LINE('  Total Customers Processed: ' || v_total_count);
    DBMS_OUTPUT.PUT_LINE('  New VIP Customers: ' || v_vip_count);
    DBMS_OUTPUT.PUT_LINE('  Non-VIP Customers: ' || (v_total_count - v_vip_count));
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END;
/

-- ============================================================
-- SCENARIO 3: Loan Due Reminders
-- Print reminders for loans due within next 30 days
-- ============================================================

DECLARE
    -- Cursor for loans due in next 30 days
    CURSOR c_due_loans IS
        SELECT l.LoanID, l.LoanAmount, l.InterestRate, l.EndDate,
               c.CustomerID, c.Name,
               TRUNC(l.EndDate - SYSDATE) AS DaysRemaining
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30
        ORDER BY l.EndDate;
    
    v_reminder_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('SCENARIO 3: LOAN DUE REMINDERS');
    DBMS_OUTPUT.PUT_LINE('Loans due within the next 30 days');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    FOR rec IN c_due_loans LOOP
        DBMS_OUTPUT.PUT_LINE('╔═══════════════════════════════════════════════╗');
        DBMS_OUTPUT.PUT_LINE('║           PAYMENT REMINDER NOTICE              ║');
        DBMS_OUTPUT.PUT_LINE('╠═══════════════════════════════════════════════╣');
        DBMS_OUTPUT.PUT_LINE('║ Dear ' || RPAD(rec.Name, 39) || '║');
        DBMS_OUTPUT.PUT_LINE('╠═══════════════════════════════════════════════╣');
        DBMS_OUTPUT.PUT_LINE('║ Loan ID: ' || RPAD(TO_CHAR(rec.LoanID), 36) || '║');
        DBMS_OUTPUT.PUT_LINE('║ Loan Amount: $' || RPAD(TO_CHAR(rec.LoanAmount, '999,999.99'), 31) || '║');
        DBMS_OUTPUT.PUT_LINE('║ Interest Rate: ' || RPAD(TO_CHAR(rec.InterestRate) || '%', 30) || '║');
        DBMS_OUTPUT.PUT_LINE('║ Due Date: ' || RPAD(TO_CHAR(rec.EndDate, 'DD-MON-YYYY'), 35) || '║');
        DBMS_OUTPUT.PUT_LINE('║ Days Remaining: ' || RPAD(TO_CHAR(rec.DaysRemaining), 29) || '║');
        DBMS_OUTPUT.PUT_LINE('╠═══════════════════════════════════════════════╣');
        
        -- Add urgency message based on days remaining
        IF rec.DaysRemaining <= 7 THEN
            DBMS_OUTPUT.PUT_LINE('║ ⚠️  URGENT: Payment due within 1 week!        ║');
        ELSIF rec.DaysRemaining <= 14 THEN
            DBMS_OUTPUT.PUT_LINE('║ ⚡ IMPORTANT: Payment due within 2 weeks      ║');
        ELSE
            DBMS_OUTPUT.PUT_LINE('║ 📌 REMINDER: Please plan your payment         ║');
        END IF;
        
        DBMS_OUTPUT.PUT_LINE('╚═══════════════════════════════════════════════╝');
        DBMS_OUTPUT.PUT_LINE('');
        
        v_reminder_count := v_reminder_count + 1;
    END LOOP;
    
    IF v_reminder_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No loans are due within the next 30 days.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('Total Reminders Sent: ' || v_reminder_count);
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    END IF;
    
END;
/

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- Verify senior citizen discounts applied
SELECT c.Name, 
       TRUNC(MONTHS_BETWEEN(SYSDATE, c.DOB) / 12) AS Age,
       l.LoanID, l.InterestRate AS "Current Interest Rate"
FROM Customers c
JOIN Loans l ON c.CustomerID = l.CustomerID
ORDER BY Age DESC;

-- Verify VIP status updates
SELECT CustomerID, Name, Balance, IsVIP
FROM Customers
ORDER BY Balance DESC;

-- Verify loans due within 30 days
SELECT l.LoanID, c.Name, l.EndDate, 
       TRUNC(l.EndDate - SYSDATE) AS "Days Until Due"
FROM Loans l
JOIN Customers c ON l.CustomerID = c.CustomerID
WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30
ORDER BY l.EndDate;
