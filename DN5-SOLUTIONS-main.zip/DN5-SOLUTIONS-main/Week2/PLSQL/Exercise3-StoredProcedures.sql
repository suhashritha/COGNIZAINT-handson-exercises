-- ============================================================
-- PL/SQL PROGRAMMING - EXERCISE 3: STORED PROCEDURES
-- DN5 Solutions
-- ============================================================

-- ============================================================
-- PREREQUISITE: Use the schema from Exercise 1
-- Run Exercise1-ControlStructures.sql first
-- ============================================================

-- Add AccountType column to Accounts if not exists
-- ALTER TABLE Accounts ADD AccountType VARCHAR2(20) DEFAULT 'Savings';

-- Insert more sample accounts data
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 5000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (2, 2, 'Savings', 15000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (3, 1, 'Checking', 3000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (4, 3, 'Savings', 8000, SYSDATE);

INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (5, 4, 'Savings', 12000, SYSDATE);

COMMIT;

-- ============================================================
-- SCENARIO 1: Process Monthly Interest for Savings Accounts
-- Applies 1% interest rate to all savings account balances
-- ============================================================

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS
    -- Variables
    v_interest_rate CONSTANT NUMBER := 0.01; -- 1% interest
    v_total_accounts NUMBER := 0;
    v_total_interest NUMBER := 0;
    v_interest_amount NUMBER;
    
    -- Cursor for savings accounts
    CURSOR c_savings_accounts IS
        SELECT AccountID, CustomerID, Balance
        FROM Accounts
        WHERE AccountType = 'Savings'
        FOR UPDATE OF Balance;
        
BEGIN
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('PROCESSING MONTHLY INTEREST FOR SAVINGS ACCOUNTS');
    DBMS_OUTPUT.PUT_LINE('Interest Rate: ' || (v_interest_rate * 100) || '%');
    DBMS_OUTPUT.PUT_LINE('Processing Date: ' || TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'));
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Process each savings account
    FOR rec IN c_savings_accounts LOOP
        -- Calculate interest
        v_interest_amount := rec.Balance * v_interest_rate;
        
        -- Update account balance
        UPDATE Accounts
        SET Balance = Balance + v_interest_amount,
            LastModified = SYSDATE
        WHERE CURRENT OF c_savings_accounts;
        
        -- Output details
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || rec.AccountID);
        DBMS_OUTPUT.PUT_LINE('  Previous Balance: $' || TO_CHAR(rec.Balance, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  Interest Added: $' || TO_CHAR(v_interest_amount, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  New Balance: $' || TO_CHAR(rec.Balance + v_interest_amount, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('');
        
        -- Update counters
        v_total_accounts := v_total_accounts + 1;
        v_total_interest := v_total_interest + v_interest_amount;
    END LOOP;
    
    -- Summary
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('MONTHLY INTEREST PROCESSING SUMMARY');
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('Total Accounts Processed: ' || v_total_accounts);
    DBMS_OUTPUT.PUT_LINE('Total Interest Disbursed: $' || TO_CHAR(v_total_interest, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
        ROLLBACK;
        RAISE;
END ProcessMonthlyInterest;
/

-- ============================================================
-- SCENARIO 2: Update Employee Bonus Based on Department
-- Updates salary by adding bonus percentage for given department
-- ============================================================

CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(
    p_department     IN VARCHAR2,
    p_bonus_percent  IN NUMBER
) AS
    -- Variables
    v_employee_count  NUMBER := 0;
    v_total_bonus     NUMBER := 0;
    v_bonus_amount    NUMBER;
    v_new_salary      NUMBER;
    
    -- Cursor for employees in department
    CURSOR c_employees IS
        SELECT EmployeeID, Name, Salary
        FROM Employees
        WHERE UPPER(Department) = UPPER(p_department)
        FOR UPDATE OF Salary;
        
BEGIN
    -- Validate bonus percentage
    IF p_bonus_percent < 0 OR p_bonus_percent > 100 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Bonus percentage must be between 0 and 100');
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('UPDATING EMPLOYEE BONUS');
    DBMS_OUTPUT.PUT_LINE('Department: ' || UPPER(p_department));
    DBMS_OUTPUT.PUT_LINE('Bonus Percentage: ' || p_bonus_percent || '%');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Process each employee
    FOR rec IN c_employees LOOP
        -- Calculate bonus
        v_bonus_amount := rec.Salary * (p_bonus_percent / 100);
        v_new_salary := rec.Salary + v_bonus_amount;
        
        -- Update salary
        UPDATE Employees
        SET Salary = v_new_salary
        WHERE CURRENT OF c_employees;
        
        -- Output details
        DBMS_OUTPUT.PUT_LINE('Employee: ' || rec.Name || ' (ID: ' || rec.EmployeeID || ')');
        DBMS_OUTPUT.PUT_LINE('  Current Salary: $' || TO_CHAR(rec.Salary, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  Bonus Amount: $' || TO_CHAR(v_bonus_amount, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  New Salary: $' || TO_CHAR(v_new_salary, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('');
        
        -- Update counters
        v_employee_count := v_employee_count + 1;
        v_total_bonus := v_total_bonus + v_bonus_amount;
    END LOOP;
    
    -- Check if any employees were found
    IF v_employee_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No employees found in department: ' || UPPER(p_department));
    ELSE
        -- Summary
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('BONUS UPDATE SUMMARY');
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('Employees Updated: ' || v_employee_count);
        DBMS_OUTPUT.PUT_LINE('Total Bonus Disbursed: $' || TO_CHAR(v_total_bonus, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('-------------------------------------------------');
    END IF;
    
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
        ROLLBACK;
        RAISE;
END UpdateEmployeeBonus;
/

-- ============================================================
-- SCENARIO 3: Transfer Funds Between Accounts
-- Transfers specified amount with sufficient balance check
-- ============================================================

CREATE OR REPLACE PROCEDURE TransferFunds(
    p_source_account_id  IN NUMBER,
    p_target_account_id  IN NUMBER,
    p_amount             IN NUMBER
) AS
    -- Variables
    v_source_balance NUMBER;
    v_target_balance NUMBER;
    v_source_exists  NUMBER;
    v_target_exists  NUMBER;
    
    -- Custom exceptions
    e_insufficient_funds EXCEPTION;
    e_invalid_amount     EXCEPTION;
    e_account_not_found  EXCEPTION;
    e_same_account       EXCEPTION;
    
BEGIN
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('FUND TRANSFER PROCESSING');
    DBMS_OUTPUT.PUT_LINE('=================================================');
    DBMS_OUTPUT.PUT_LINE('Transfer Request:');
    DBMS_OUTPUT.PUT_LINE('  From Account: ' || p_source_account_id);
    DBMS_OUTPUT.PUT_LINE('  To Account: ' || p_target_account_id);
    DBMS_OUTPUT.PUT_LINE('  Amount: $' || TO_CHAR(p_amount, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Validate transfer amount
    IF p_amount <= 0 THEN
        RAISE e_invalid_amount;
    END IF;
    
    -- Check if transferring to same account
    IF p_source_account_id = p_target_account_id THEN
        RAISE e_same_account;
    END IF;
    
    -- Check if source account exists
    SELECT COUNT(*) INTO v_source_exists
    FROM Accounts
    WHERE AccountID = p_source_account_id;
    
    IF v_source_exists = 0 THEN
        RAISE e_account_not_found;
    END IF;
    
    -- Check if target account exists
    SELECT COUNT(*) INTO v_target_exists
    FROM Accounts
    WHERE AccountID = p_target_account_id;
    
    IF v_target_exists = 0 THEN
        RAISE e_account_not_found;
    END IF;
    
    -- Get source account balance
    SELECT Balance INTO v_source_balance
    FROM Accounts
    WHERE AccountID = p_source_account_id
    FOR UPDATE;
    
    -- Check for sufficient funds
    IF v_source_balance < p_amount THEN
        RAISE e_insufficient_funds;
    END IF;
    
    -- Get target account balance (for logging)
    SELECT Balance INTO v_target_balance
    FROM Accounts
    WHERE AccountID = p_target_account_id
    FOR UPDATE;
    
    DBMS_OUTPUT.PUT_LINE('Pre-Transfer Balances:');
    DBMS_OUTPUT.PUT_LINE('  Source Account Balance: $' || TO_CHAR(v_source_balance, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('  Target Account Balance: $' || TO_CHAR(v_target_balance, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('');
    
    -- Perform the transfer
    -- Debit from source
    UPDATE Accounts
    SET Balance = Balance - p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_source_account_id;
    
    -- Credit to target
    UPDATE Accounts
    SET Balance = Balance + p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_target_account_id;
    
    -- Record transaction (withdrawal from source)
    INSERT INTO Transactions (
        TransactionID, AccountID, TransactionDate, 
        Amount, TransactionType
    ) VALUES (
        (SELECT NVL(MAX(TransactionID), 0) + 1 FROM Transactions),
        p_source_account_id, SYSDATE, 
        p_amount, 'Transfer'
    );
    
    -- Record transaction (deposit to target)
    INSERT INTO Transactions (
        TransactionID, AccountID, TransactionDate, 
        Amount, TransactionType
    ) VALUES (
        (SELECT NVL(MAX(TransactionID), 0) + 1 FROM Transactions),
        p_target_account_id, SYSDATE, 
        p_amount, 'Transfer'
    );
    
    -- Display success message
    DBMS_OUTPUT.PUT_LINE('✓ TRANSFER SUCCESSFUL');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Post-Transfer Balances:');
    DBMS_OUTPUT.PUT_LINE('  Source Account Balance: $' || TO_CHAR(v_source_balance - p_amount, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('  Target Account Balance: $' || TO_CHAR(v_target_balance + p_amount, '999,999.99'));
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('Transaction ID generated for audit trail.');
    
    COMMIT;
    
EXCEPTION
    WHEN e_invalid_amount THEN
        DBMS_OUTPUT.PUT_LINE('✗ ERROR: Invalid transfer amount. Amount must be positive.');
        ROLLBACK;
        
    WHEN e_same_account THEN
        DBMS_OUTPUT.PUT_LINE('✗ ERROR: Cannot transfer to the same account.');
        ROLLBACK;
        
    WHEN e_account_not_found THEN
        DBMS_OUTPUT.PUT_LINE('✗ ERROR: One or both accounts do not exist.');
        ROLLBACK;
        
    WHEN e_insufficient_funds THEN
        DBMS_OUTPUT.PUT_LINE('✗ ERROR: Insufficient funds in source account.');
        DBMS_OUTPUT.PUT_LINE('  Available Balance: $' || TO_CHAR(v_source_balance, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  Requested Amount: $' || TO_CHAR(p_amount, '999,999.99'));
        DBMS_OUTPUT.PUT_LINE('  Shortfall: $' || TO_CHAR(p_amount - v_source_balance, '999,999.99'));
        ROLLBACK;
        
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✗ ERROR: ' || SQLERRM);
        ROLLBACK;
        RAISE;
END TransferFunds;
/

-- ============================================================
-- TESTING THE STORED PROCEDURES
-- ============================================================

-- Enable server output
SET SERVEROUTPUT ON SIZE UNLIMITED;

-- Test 1: Process Monthly Interest
DBMS_OUTPUT.PUT_LINE('');
DBMS_OUTPUT.PUT_LINE('===== TEST 1: PROCESSING MONTHLY INTEREST =====');
EXEC ProcessMonthlyInterest;

-- Test 2: Update Employee Bonus for IT Department (10% bonus)
DBMS_OUTPUT.PUT_LINE('');
DBMS_OUTPUT.PUT_LINE('===== TEST 2: UPDATE EMPLOYEE BONUS =====');
EXEC UpdateEmployeeBonus('IT', 10);

-- Test 3: Transfer Funds - Successful Transfer
DBMS_OUTPUT.PUT_LINE('');
DBMS_OUTPUT.PUT_LINE('===== TEST 3: FUND TRANSFER (SUCCESSFUL) =====');
EXEC TransferFunds(1, 2, 500);

-- Test 4: Transfer Funds - Insufficient Funds
DBMS_OUTPUT.PUT_LINE('');
DBMS_OUTPUT.PUT_LINE('===== TEST 4: FUND TRANSFER (INSUFFICIENT FUNDS) =====');
EXEC TransferFunds(3, 4, 100000);

-- Test 5: Transfer Funds - Invalid Amount
DBMS_OUTPUT.PUT_LINE('');
DBMS_OUTPUT.PUT_LINE('===== TEST 5: FUND TRANSFER (INVALID AMOUNT) =====');
EXEC TransferFunds(1, 2, -100);

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- View all accounts after interest processing
SELECT AccountID, CustomerID, AccountType, 
       Balance, LastModified
FROM Accounts
ORDER BY AccountID;

-- View all employees after bonus update
SELECT EmployeeID, Name, Department, Salary
FROM Employees
ORDER BY Department, EmployeeID;

-- View recent transactions
SELECT TransactionID, AccountID, TransactionDate,
       Amount, TransactionType
FROM Transactions
ORDER BY TransactionDate DESC;
