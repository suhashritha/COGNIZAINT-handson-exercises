package com.testing.junit;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

/*
 * JUnit 5 Assertions Exercise.
 * EXERCISE 3: JUNIT ASSERTIONS
 * ============================
 * This exercise demonstrates all major JUnit 5 assertions:
 * - assertEquals / assertNotEquals
 * - assertTrue / assertFalse
 * - assertNull / assertNotNull
 * - assertSame / assertNotSame
 * - assertThrows / assertDoesNotThrow
 * - assertAll (grouped assertions)
 * - assertArrayEquals
 * - assertIterableEquals
 * - assertTimeout / assertTimeoutPreemptively
 */
@DisplayName("JUnit 5 Assertions Demo")
class AssertionsExerciseTest {
    
    private Calculator calculator;
    
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }
    
    // =========================================
    // assertEquals / assertNotEquals
    // =========================================
    
    @Test
    @DisplayName("assertEquals - Verify exact values")
    void testAssertEquals() {
        // Basic equality check
        assertEquals(4, calculator.add(2, 2));
        
        // With custom message
        assertEquals(4, calculator.add(2, 2), "2 + 2 should equal 4");
        
        // With lazy message (computed only on failure)
        assertEquals(4, calculator.add(2, 2), 
            () -> "Sum of 2 and 2 should be 4");
        
        // String equality
        String expected = "Hello";
        String actual = "Hello";
        assertEquals(expected, actual);
        
        // Floating point with delta
        assertEquals(3.14, 3.141592, 0.01, "Pi approximation");
    }
    
    @Test
    @DisplayName("assertNotEquals - Verify values differ")
    void testAssertNotEquals() {
        assertNotEquals(5, calculator.add(2, 2));
        assertNotEquals("Hello", "World");
    }
    
    // =========================================
    // assertTrue / assertFalse
    // =========================================
    
    @Test
    @DisplayName("assertTrue / assertFalse - Boolean conditions")
    void testAssertTrueAndFalse() {
        // assertTrue
        assertTrue(calculator.isEven(4), "4 should be even");
        assertTrue(calculator.isPrime(7), "7 should be prime");
        assertTrue(5 > 3);
        
        // assertFalse
        assertFalse(calculator.isEven(5), "5 should not be even");
        assertFalse(calculator.isPrime(4), "4 should not be prime");
        assertFalse(3 > 5);
    }
    
    // =========================================
    // assertNull / assertNotNull
    // =========================================
    
    @Test
    @DisplayName("assertNull / assertNotNull - Null checks")
    void testNullAssertions() {
        String nullString = null;
        String nonNullString = "Hello";
        
        assertNull(nullString, "Should be null");
        assertNotNull(nonNullString, "Should not be null");
        assertNotNull(calculator, "Calculator should be initialized");
    }
    
    // =========================================
    // assertSame / assertNotSame
    // =========================================
    
    @Test
    @DisplayName("assertSame / assertNotSame - Reference equality")
    void testSameAssertions() {
        String str1 = new String("Hello");
        String str2 = new String("Hello");
        String str3 = str1;
        
        // Different objects with same content
        assertEquals(str1, str2);        // Content is equal
        assertNotSame(str1, str2);       // Different references
        
        // Same reference
        assertSame(str1, str3);          // Same reference
    }
    
    // =========================================
    // assertThrows / assertDoesNotThrow
    // =========================================
    
    @Test
    @DisplayName("assertThrows - Verify exceptions are thrown")
    void testAssertThrows() {
        // Basic exception assertion
        assertThrows(ArithmeticException.class, 
            () -> calculator.divide(10, 0));
        
        // Capture and verify exception
        ArithmeticException exception = assertThrows(
            ArithmeticException.class,
            () -> calculator.divide(10, 0),
            "Division by zero should throw exception"
        );
        
        // Verify exception message
        assertTrue(exception.getMessage().contains("divide by zero"));
        
        // IllegalArgumentException
        assertThrows(IllegalArgumentException.class,
            () -> calculator.factorial(-5));
    }
    
    @Test
    @DisplayName("assertDoesNotThrow - Verify no exception")
    void testAssertDoesNotThrow() {
        assertDoesNotThrow(() -> calculator.divide(10, 2));
        assertDoesNotThrow(() -> calculator.factorial(5));
        
        // With return value
        int result = assertDoesNotThrow(() -> calculator.add(2, 3));
        assertEquals(5, result);
    }
    
    // =========================================
    // assertAll - Grouped Assertions
    // =========================================
    
    @Test
    @DisplayName("assertAll - Group multiple assertions")
    void testAssertAll() {
        // All assertions run even if some fail
        assertAll("Calculator operations",
            () -> assertEquals(5, calculator.add(2, 3)),
            () -> assertEquals(2, calculator.subtract(5, 3)),
            () -> assertEquals(12, calculator.multiply(3, 4)),
            () -> assertEquals(5, calculator.divide(10, 2))
        );
        
        // Named assertions for better failure messages
        assertAll("Prime number checks",
            () -> assertTrue(calculator.isPrime(2), "2 is prime"),
            () -> assertTrue(calculator.isPrime(3), "3 is prime"),
            () -> assertTrue(calculator.isPrime(5), "5 is prime"),
            () -> assertFalse(calculator.isPrime(4), "4 is not prime")
        );
    }
    
    // =========================================
    // assertArrayEquals
    // =========================================
    
    @Test
    @DisplayName("assertArrayEquals - Compare arrays")
    void testAssertArrayEquals() {
        int[] expected = {1, 2, 3, 4, 5};
        int[] actual = {1, 2, 3, 4, 5};
        
        assertArrayEquals(expected, actual);
        
        // String arrays
        String[] names1 = {"Alice", "Bob", "Charlie"};
        String[] names2 = {"Alice", "Bob", "Charlie"};
        assertArrayEquals(names1, names2);
    }
    
    // =========================================
    // assertIterableEquals
    // =========================================
    
    @Test
    @DisplayName("assertIterableEquals - Compare collections")
    void testAssertIterableEquals() {
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> actual = Arrays.asList(1, 2, 3, 4, 5);
        
        assertIterableEquals(expected, actual);
        
        // Lists with strings
        List<String> names1 = List.of("Alice", "Bob", "Charlie");
        List<String> names2 = List.of("Alice", "Bob", "Charlie");
        assertIterableEquals(names1, names2);
    }
    
    // =========================================
    // assertTimeout - Time constraints
    // =========================================
    
    @Test
    @DisplayName("assertTimeout - Verify operation completes in time")
    void testAssertTimeout() {
        // Operation should complete within 1 second
        assertTimeout(Duration.ofSeconds(1), () -> {
            // Simulate quick operation
            int result = calculator.factorial(10);
            assertEquals(3628800, result);
        });
        
        // With return value
        long result = assertTimeout(Duration.ofMillis(500), () -> {
            return calculator.factorial(5);
        });
        assertEquals(120, result);
    }
    
    @Test
    @DisplayName("assertTimeoutPreemptively - Strict timeout")
    void testAssertTimeoutPreemptively() {
        // This will abort if timeout exceeded
        assertTimeoutPreemptively(Duration.ofSeconds(1), () -> {
            calculator.add(1, 1);
        });
    }
    
    // =========================================
    // assertLinesMatch - Pattern matching for lines
    // =========================================
    
    @Test
    @DisplayName("assertLinesMatch - Compare lines with patterns")
    void testAssertLinesMatch() {
        List<String> expected = List.of(
            "Line 1",
            "\\d+ items",  // Regex pattern
            "Line 3"
        );
        
        List<String> actual = List.of(
            "Line 1",
            "42 items",
            "Line 3"
        );
        
        assertLinesMatch(expected, actual);
    }
}
