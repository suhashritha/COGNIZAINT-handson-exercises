package com.testing.mockito;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/*
 * Mockito Exercise 2: Verifying Interactions.
 * EXERCISE 2: VERIFYING INTERACTIONS
 * ==================================
 * This exercise demonstrates:
 * - verify() - Verify method was called
 * - verify(times(n)) - Verify exact call count
 * - verify(never()) - Verify method was never called
 * - verify(atLeast(n)) - Verify minimum call count
 * - verify(atMost(n)) - Verify maximum call count
 * - verifyNoMoreInteractions() - No unverified calls
 * - verifyNoInteractions() - No calls at all
 * - Argument Captors (@Captor)
 * - InOrder verification
 * Why Verify Interactions?
 * -----------------------
 * - Ensure dependencies are called correctly
 * - Verify side effects (like saving to database)
 * - Check method call order
 * - Validate arguments passed to dependencies
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Mockito Verifying Interactions Exercise")
class VerifyingInteractionsTest {
    
    @Mock
    private UserRepository userRepository;
    
    @InjectMocks
    private UserService userService;
    
    @Captor
    private ArgumentCaptor<User> userCaptor;
    
    @Captor
    private ArgumentCaptor<Long> idCaptor;
    
    private User testUser;
    
    @BeforeEach
    void setUp() {
        testUser = new User(1L, "John Doe", "john@example.com");
    }
    
    // =========================================
    // Basic verify() - Method Was Called
    // =========================================
    
    @Test
    @DisplayName("Verify method was called")
    void testVerifyMethodCalled() {
        // ARRANGE
        when(userRepository.findById(1L)).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        
        // ASSERT: Verify findById was called with argument 1L
        verify(userRepository).findById(1L);
    }
    
    @Test
    @DisplayName("Verify method was called with any argument")
    void testVerifyWithAnyArgument() {
        // ARRANGE
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT
        userService.getUserById(42L);
        
        // ASSERT
        verify(userRepository).findById(anyLong());
    }
    
    // =========================================
    // verify(times(n)) - Exact Call Count
    // =========================================
    
    @Test
    @DisplayName("Verify method called exact number of times")
    void testVerifyTimesN() {
        // ARRANGE
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT: Call multiple times
        userService.getUserById(1L);
        userService.getUserById(2L);
        userService.getUserById(3L);
        
        // ASSERT: Verify called exactly 3 times
        verify(userRepository, times(3)).findById(anyLong());
    }
    
    @Test
    @DisplayName("Verify method called once (explicit)")
    void testVerifyCalledOnce() {
        // ARRANGE
        when(userRepository.findById(1L)).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        
        // ASSERT: times(1) is same as default verify
        verify(userRepository, times(1)).findById(1L);
    }
    
    // =========================================
    // verify(never()) - Method Never Called
    // =========================================
    
    @Test
    @DisplayName("Verify method was never called")
    void testVerifyNever() {
        // ARRANGE
        when(userRepository.findByEmail("test@example.com")).thenReturn(testUser);
        
        // ACT: Create user with existing email - throws exception
        assertThrows(IllegalArgumentException.class,
            () -> userService.createUser("Test", "test@example.com"));
        
        // ASSERT: save() should never be called because email exists
        verify(userRepository, never()).save(any(User.class));
    }
    
    // =========================================
    // verify(atLeast/atMost) - Range of Calls
    // =========================================
    
    @Test
    @DisplayName("Verify at least N calls")
    void testVerifyAtLeast() {
        // ARRANGE
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        userService.getUserById(2L);
        userService.getUserById(3L);
        
        // ASSERT: At least 2 calls
        verify(userRepository, atLeast(2)).findById(anyLong());
    }
    
    @Test
    @DisplayName("Verify at most N calls")
    void testVerifyAtMost() {
        // ARRANGE
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        userService.getUserById(2L);
        
        // ASSERT: At most 3 calls (we made 2)
        verify(userRepository, atMost(3)).findById(anyLong());
    }
    
    @Test
    @DisplayName("Verify at least once")
    void testVerifyAtLeastOnce() {
        // ARRANGE
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        userService.getUserById(2L);
        
        // ASSERT
        verify(userRepository, atLeastOnce()).findById(anyLong());
    }
    
    // =========================================
    // verifyNoMoreInteractions()
    // =========================================
    
    @Test
    @DisplayName("Verify no more interactions after specific calls")
    void testVerifyNoMoreInteractions() {
        // ARRANGE
        when(userRepository.findById(1L)).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        
        // ASSERT: Verify the specific call happened
        verify(userRepository).findById(1L);
        
        // ASSERT: No other interactions with the mock
        verifyNoMoreInteractions(userRepository);
    }
    
    // =========================================
    // verifyNoInteractions()
    // =========================================
    
    @Test
    @DisplayName("Verify no interactions at all")
    void testVerifyNoInteractions() {
        // ACT: Do nothing with the service
        // (maybe some validation that doesn't call repo)
        
        // ASSERT: Repository should not be called
        verifyNoInteractions(userRepository);
    }
    
    // =========================================
    // ArgumentCaptor - Capture Arguments
    // =========================================
    
    @Test
    @DisplayName("Capture arguments passed to mock")
    void testArgumentCaptor() {
        // ARRANGE
        when(userRepository.findByEmail(anyString())).thenReturn(null);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> {
            User u = inv.getArgument(0);
            u.setId(100L);
            return u;
        });
        
        // ACT
        userService.createUser("Test User", "test@example.com");
        
        // ASSERT: Capture and verify argument
        verify(userRepository).save(userCaptor.capture());
        
        User capturedUser = userCaptor.getValue();
        assertEquals("Test User", capturedUser.getName());
        assertEquals("test@example.com", capturedUser.getEmail());
    }
    
    @Test
    @DisplayName("Capture multiple arguments")
    void testCaptureMultipleArguments() {
        // ARRANGE
        when(userRepository.existsById(anyLong())).thenReturn(true);
        doNothing().when(userRepository).deleteById(anyLong());
        
        // ACT: Delete multiple users
        userService.deleteUser(1L);
        userService.deleteUser(2L);
        userService.deleteUser(3L);
        
        // ASSERT: Capture all arguments
        verify(userRepository, times(3)).deleteById(idCaptor.capture());
        
        // Get all captured values
        var capturedIds = idCaptor.getAllValues();
        assertEquals(3, capturedIds.size());
        assertTrue(capturedIds.contains(1L));
        assertTrue(capturedIds.contains(2L));
        assertTrue(capturedIds.contains(3L));
    }
    
    // =========================================
    // InOrder Verification
    // =========================================
    
    @Test
    @DisplayName("Verify methods called in order")
    void testInOrderVerification() {
        // ARRANGE
        when(userRepository.findByEmail(anyString())).thenReturn(null);
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        
        // ACT
        userService.createUser("Test", "test@example.com");
        
        // ASSERT: Verify order of calls
        InOrder inOrder = inOrder(userRepository);
        inOrder.verify(userRepository).findByEmail(anyString()); // First
        inOrder.verify(userRepository).save(any(User.class));    // Second
    }
    
    @Test
    @DisplayName("Verify complex order with multiple mocks")
    void testInOrderWithMultipleMocks() {
        // ARRANGE
        UserRepository mockRepo1 = mock(UserRepository.class);
        UserRepository mockRepo2 = mock(UserRepository.class);
        
        // ACT
        mockRepo1.findById(1L);
        mockRepo2.findById(2L);
        mockRepo1.count();
        
        // ASSERT: Verify order across both mocks
        InOrder inOrder = inOrder(mockRepo1, mockRepo2);
        inOrder.verify(mockRepo1).findById(1L);
        inOrder.verify(mockRepo2).findById(2L);
        inOrder.verify(mockRepo1).count();
    }
    
    // =========================================
    // Verifying Void Method Calls
    // =========================================
    
    @Test
    @DisplayName("Verify void method was called")
    void testVerifyVoidMethod() {
        // ARRANGE
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);
        
        // ACT
        userService.deleteUser(1L);
        
        // ASSERT
        verify(userRepository).existsById(1L);
        verify(userRepository).deleteById(1L);
    }
    
    // =========================================
    // Verify with Timeout
    // =========================================
    
    @Test
    @DisplayName("Verify with timeout")
    void testVerifyWithTimeout() {
        // ARRANGE
        when(userRepository.findById(1L)).thenReturn(testUser);
        
        // ACT
        userService.getUserById(1L);
        
        // ASSERT: Verify call happened within timeout
        verify(userRepository, timeout(100)).findById(1L);
    }
    
    // =========================================
    // Real World Scenario: Create and Update
    // =========================================
    
    @Test
    @DisplayName("Verify complete create and update workflow")
    void testCreateAndUpdateWorkflow() {
        // ARRANGE
        when(userRepository.findByEmail("new@example.com")).thenReturn(null);
        when(userRepository.findById(1L)).thenReturn(testUser);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> {
            User u = inv.getArgument(0);
            if (u.getId() == null) u.setId(1L);
            return u;
        });
        
        // ACT: Create user
        User created = userService.createUser("New User", "new@example.com");
        
        // ACT: Update user
        User updated = userService.updateUser(1L, "Updated User", "updated@example.com");
        
        // ASSERT: Verify interactions in order
        InOrder inOrder = inOrder(userRepository);
        
        // Create workflow
        inOrder.verify(userRepository).findByEmail("new@example.com");
        inOrder.verify(userRepository).save(any(User.class));
        
        // Update workflow
        inOrder.verify(userRepository).findById(1L);
        inOrder.verify(userRepository).save(any(User.class));
        
        // Total of 2 save calls
        verify(userRepository, times(2)).save(any(User.class));
    }
}
