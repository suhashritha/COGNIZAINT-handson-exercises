package com.testing.junit;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/*
 * JUnit 5 Test Class for Calculator.
 * EXERCISE 1: SETTING UP JUNIT
 * ============================
 * This exercise demonstrates:
 * - JUnit 5 project setup with Maven/Gradle
 * - Basic test class structure
 * - @Test annotation usage
 * - Test lifecycle annotations
 * - Running tests
 * Dependencies (pom.xml):
 * -----------------------
 * <dependency>
 *     <groupId>org.junit.jupiter</groupId>
 *     <artifactId>junit-jupiter</artifactId>
 *     <version>5.10.0</version>
 *     <scope>test</scope>
 * </dependency>
 * Test Lifecycle:
 * ---------------
 * @BeforeAll  -> Runs once before all tests
 * @BeforeEach -> Runs before each test method
 * @Test       -> Marks a test method
 * @AfterEach  -> Runs after each test method
 * @AfterAll   -> Runs once after all tests
 */
@DisplayName("Calculator Test Suite")
class CalculatorTest {
    
    // System Under Test
    private Calculator calculator;
    
    // Test counter for demonstration
    private static int testCount = 0;
    
    /*
     * Runs once before all tests.
     * Use for expensive setup operations.
     */
    @BeforeAll
    static void setUpBeforeAll() {
        System.out.println("================================================");
        System.out.println("JUnit 5 Test Execution Started");
        System.out.println("================================================");
    }
    
    /*
     * Runs before each test method.
     * Use to initialize objects needed for each test.
     */
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
        testCount++;
        System.out.println("\n--- Test #" + testCount + " Starting ---");
    }
    
    /*
     * Basic test for addition.
     */
    @Test
    @DisplayName("Test Addition: 2 + 3 = 5")
    void testAddition() {
        int result = calculator.add(2, 3);
        assertEquals(5, result, "2 + 3 should equal 5");
        System.out.println("✓ Addition test passed: 2 + 3 = " + result);
    }
    
    /*
     * Test addition with negative numbers.
     */
    @Test
    @DisplayName("Test Addition with Negatives: -5 + 3 = -2")
    void testAdditionWithNegatives() {
        int result = calculator.add(-5, 3);
        assertEquals(-2, result);
        System.out.println("✓ Addition with negatives passed: -5 + 3 = " + result);
    }
    
    /*
     * Basic test for subtraction.
     */
    @Test
    @DisplayName("Test Subtraction: 10 - 4 = 6")
    void testSubtraction() {
        int result = calculator.subtract(10, 4);
        assertEquals(6, result);
        System.out.println("✓ Subtraction test passed: 10 - 4 = " + result);
    }
    
    /*
     * Basic test for multiplication.
     */
    @Test
    @DisplayName("Test Multiplication: 4 × 5 = 20")
    void testMultiplication() {
        int result = calculator.multiply(4, 5);
        assertEquals(20, result);
        System.out.println("✓ Multiplication test passed: 4 × 5 = " + result);
    }
    
    /*
     * Basic test for division.
     */
    @Test
    @DisplayName("Test Division: 20 ÷ 4 = 5")
    void testDivision() {
        int result = calculator.divide(20, 4);
        assertEquals(5, result);
        System.out.println("✓ Division test passed: 20 ÷ 4 = " + result);
    }
    
    /*
     * Test division by zero throws exception.
     */
    @Test
    @DisplayName("Test Division by Zero throws ArithmeticException")
    void testDivisionByZero() {
        ArithmeticException exception = assertThrows(
            ArithmeticException.class,
            () -> calculator.divide(10, 0),
            "Division by zero should throw ArithmeticException"
        );
        
        assertTrue(exception.getMessage().contains("Cannot divide by zero"));
        System.out.println("✓ Division by zero correctly throws exception");
    }
    
    /*
     * Runs after each test method.
     */
    @AfterEach
    void tearDown() {
        System.out.println("--- Test completed ---");
    }
    
    /*
     * Runs once after all tests.
     */
    @AfterAll
    static void tearDownAfterAll() {
        System.out.println("\n================================================");
        System.out.println("All Tests Completed: " + testCount + " tests executed");
        System.out.println("================================================");
    }
}
