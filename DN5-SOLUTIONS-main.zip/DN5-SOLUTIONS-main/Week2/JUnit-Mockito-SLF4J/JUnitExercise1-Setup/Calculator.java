package com.testing.junit;

/*
 * Calculator class for demonstrating JUnit testing.
 * This is the System Under Test (SUT) for JUnit exercises.
 */
public class Calculator {
    
    /*
     * Adds two numbers.
     * @param a First number
     * @param b Second number
     * @return Sum of a and b
     */
    public int add(int a, int b) {
        return a + b;
    }
    
    /*
     * Subtracts second number from first.
     * @param a First number
     * @param b Second number
     * @return Difference (a - b)
     */
    public int subtract(int a, int b) {
        return a - b;
    }
    
    /*
     * Multiplies two numbers.
     * @param a First number
     * @param b Second number
     * @return Product of a and b
     */
    public int multiply(int a, int b) {
        return a * b;
    }
    
    /*
     * Divides first number by second.
     * @param a Dividend
     * @param b Divisor
     * @return Quotient (a / b)
     * @throws ArithmeticException if b is zero
     */
    public int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }
    
    /*
     * Calculates the power of a number.
     * @param base The base number
     * @param exponent The exponent
     * @return base raised to the power of exponent
     */
    public double power(double base, int exponent) {
        return Math.pow(base, exponent);
    }
    
    /*
     * Calculates factorial of a number.
     * @param n The number
     * @return Factorial of n
     * @throws IllegalArgumentException if n is negative
     */
    public long factorial(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Factorial is not defined for negative numbers");
        }
        if (n == 0 || n == 1) {
            return 1;
        }
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
    
    /*
     * Checks if a number is even.
     * @param n The number to check
     * @return true if even, false otherwise
     */
    public boolean isEven(int n) {
        return n % 2 == 0;
    }
    
    /*
     * Checks if a number is prime.
     * @param n The number to check
     * @return true if prime, false otherwise
     */
    public boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }
}
