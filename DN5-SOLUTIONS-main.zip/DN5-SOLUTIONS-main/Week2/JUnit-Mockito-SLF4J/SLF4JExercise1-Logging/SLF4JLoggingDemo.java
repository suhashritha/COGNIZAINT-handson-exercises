package com.testing.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.BigDecimal;

/*
 * SLF4J Logging Demo Application.
 * SLF4J EXERCISE 1: LOGGING
 * =========================
 * This demo shows:
 * 1. Creating loggers
 * 2. Using different log levels
 * 3. Parameterized logging
 * 4. Conditional logging
 * 5. Exception logging
 * 6. MDC (Mapped Diagnostic Context)
 * To run this demo:
 * 1. Add SLF4J and Logback dependencies to pom.xml
 * 2. Place logback.xml in src/main/resources
 * 3. Run this main class
 */
public class SLF4JLoggingDemo {
    
    // Create logger instance - best practice: use class name
    private static final Logger logger = LoggerFactory.getLogger(SLF4JLoggingDemo.class);
    
    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("SLF4J LOGGING DEMONSTRATION");
        System.out.println("================================================\n");
        
        // Demo 1: Basic Log Levels
        demonstrateLogLevels();
        
        // Demo 2: Parameterized Logging
        demonstrateParameterizedLogging();
        
        // Demo 3: Conditional Logging
        demonstrateConditionalLogging();
        
        // Demo 4: Exception Logging
        demonstrateExceptionLogging();
        
        // Demo 5: Real-World Payment Scenario
        demonstratePaymentScenario();
        
        System.out.println("\n================================================");
        System.out.println("DEMO COMPLETED - Check console and log files");
        System.out.println("================================================");
    }
    
    /*
     * Demonstrates all log levels.
     */
    private static void demonstrateLogLevels() {
        System.out.println("\n--- Demo 1: Log Levels ---");
        
        // TRACE: Most detailed, for tracing code execution
        logger.trace("TRACE: Entering method demonstrateLogLevels()");
        
        // DEBUG: Detailed information for debugging
        logger.debug("DEBUG: Processing step 1 of 5");
        
        // INFO: General application flow
        logger.info("INFO: Application started successfully");
        
        // WARN: Potentially harmful situations
        logger.warn("WARN: Configuration file not found, using defaults");
        
        // ERROR: Error events that might still allow running
        logger.error("ERROR: Failed to connect to backup server");
        
        logger.trace("TRACE: Exiting method demonstrateLogLevels()");
    }
    
    /*
     * Demonstrates parameterized logging.
     */
    private static void demonstrateParameterizedLogging() {
        System.out.println("\n--- Demo 2: Parameterized Logging ---");
        
        String userId = "USR-12345";
        String action = "LOGIN";
        int attempts = 3;
        
        // GOOD: Parameterized logging - efficient
        logger.info("User {} performed action: {}", userId, action);
        logger.info("Login attempt {} of {}", attempts, 5);
        
        // GOOD: Multiple parameters
        logger.info("User {} from {} performed {} at timestamp {}",
            userId, "192.168.1.1", action, System.currentTimeMillis());
        
        // BAD: String concatenation - less efficient
        // logger.info("User " + userId + " performed action: " + action);
        // The above is evaluated even if INFO level is disabled
        
        // GOOD: Using placeholders {}
        BigDecimal amount = new BigDecimal("1500.00");
        logger.info("Transaction amount: {} USD", amount);
    }
    
    /*
     * Demonstrates conditional logging.
     */
    private static void demonstrateConditionalLogging() {
        System.out.println("\n--- Demo 3: Conditional Logging ---");
        
        // Check if DEBUG is enabled before expensive operations
        if (logger.isDebugEnabled()) {
            String expensiveData = performExpensiveOperation();
            logger.debug("Expensive data: {}", expensiveData);
        }
        
        // Check if TRACE is enabled
        if (logger.isTraceEnabled()) {
            logger.trace("Very detailed trace information: {}", 
                buildDetailedTraceInfo());
        }
        
        logger.info("Conditional logging checks completed");
    }
    
    /*
     * Demonstrates exception logging.
     */
    private static void demonstrateExceptionLogging() {
        System.out.println("\n--- Demo 4: Exception Logging ---");
        
        try {
            // Simulate an exception
            throw new RuntimeException("Simulated database connection failure");
        } catch (Exception e) {
            // GOOD: Log exception with message and stack trace
            logger.error("Database operation failed", e);
        }
        
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            // GOOD: Include context in error message
            logger.error("Calculation failed for input: dividend=10, divisor=0", e);
        }
        
        try {
            String nullString = null;
            nullString.length();
        } catch (NullPointerException e) {
            // GOOD: Use parameterized logging even with exceptions
            String operation = "string length calculation";
            logger.error("Failed to perform {}: {}", operation, e.getMessage(), e);
        }
    }
    
    /*
     * Demonstrates a real-world payment scenario.
     */
    private static void demonstratePaymentScenario() {
        System.out.println("\n--- Demo 5: Payment Service Scenario ---");
        
        PaymentService paymentService = new PaymentService();
        
        // Successful payment
        try {
            String txnId = paymentService.processPayment(
                "USER-001", 
                new BigDecimal("500.00"), 
                "USD"
            );
            logger.info("Payment completed: {}", txnId);
        } catch (Exception e) {
            logger.error("Payment failed", e);
        }
        
        // Large transaction (triggers warning)
        try {
            String txnId = paymentService.processPayment(
                "USER-002", 
                new BigDecimal("15000.00"), 
                "USD"
            );
            logger.info("Large payment completed: {}", txnId);
        } catch (Exception e) {
            logger.error("Large payment failed", e);
        }
        
        // Invalid payment (triggers exception)
        try {
            paymentService.processPayment(
                "USER-003", 
                new BigDecimal("-100.00"), 
                "USD"
            );
        } catch (Exception e) {
            logger.warn("Expected error for invalid payment: {}", e.getMessage());
        }
        
        // Batch payments
        PaymentService.PaymentRequest[] batch = {
            new PaymentService.PaymentRequest("USER-A", new BigDecimal("100.00"), "USD"),
            new PaymentService.PaymentRequest("USER-B", new BigDecimal("200.00"), "USD"),
            new PaymentService.PaymentRequest("USER-C", new BigDecimal("-50.00"), "USD"), // Will fail
            new PaymentService.PaymentRequest("USER-D", new BigDecimal("300.00"), "USD")
        };
        
        paymentService.processBatchPayments(batch);
    }
    
    // Helper methods
    
    private static String performExpensiveOperation() {
        // Simulate expensive computation
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 1000; i++) {
            sb.append(i).append(",");
        }
        return sb.toString();
    }
    
    private static String buildDetailedTraceInfo() {
        return "Thread: " + Thread.currentThread().getName() + 
               ", Memory: " + Runtime.getRuntime().freeMemory() +
               ", Time: " + System.currentTimeMillis();
    }
}
