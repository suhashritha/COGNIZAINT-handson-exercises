package com.testing.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.BigDecimal;

/*
 * Payment Service demonstrating SLF4J Logging.
 * EXERCISE 1: SLF4J LOGGING
 * =========================
 * SLF4J Logging Levels (in order of severity):
 * - TRACE: Fine-grained debug information
 * - DEBUG: Detailed debug information
 * - INFO:  General application flow information
 * - WARN:  Potentially harmful situations
 * - ERROR: Error events that might still allow running
 * SLF4J Best Practices:
 * --------------------
 * 1. Use parameterized logging: logger.info("User {} logged in", userId)
 * 2. Check log level before expensive operations: if(logger.isDebugEnabled())
 * 3. Include context information in log messages
 * 4. Use appropriate log levels for different situations
 * 5. Don't log sensitive information (passwords, tokens)
 */
public class PaymentService {
    
    // Create logger for this class
    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);
    
    private final String serviceName = "PaymentService";
    
    /*
     * Process a payment transaction.
     * @param userId User making the payment
     * @param amount Payment amount
     * @param currency Currency code
     * @return Transaction ID
     */
    public String processPayment(String userId, BigDecimal amount, String currency) {
        
        // TRACE: Entry point logging
        logger.trace("Entering processPayment() - userId: {}, amount: {}, currency: {}",
            userId, amount, currency);
        
        // INFO: Business operation start
        logger.info("Processing payment for user: {}, amount: {} {}", 
            userId, amount, currency);
        
        // Validate input
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            logger.warn("Invalid payment amount: {} for user: {}", amount, userId);
            throw new IllegalArgumentException("Payment amount must be positive");
        }
        
        // DEBUG: Detailed processing information
        logger.debug("Validating user {} for payment of {} {}", userId, amount, currency);
        
        try {
            // Simulate payment processing
            String transactionId = generateTransactionId(userId, amount);
            
            // Simulate potential issues
            if (amount.compareTo(new BigDecimal("10000")) > 0) {
                logger.warn("Large transaction detected: {} {} for user: {}. " +
                    "Flagging for review.", amount, currency, userId);
            }
            
            // INFO: Successful completion
            logger.info("Payment processed successfully. Transaction ID: {}, User: {}, Amount: {} {}",
                transactionId, userId, amount, currency);
            
            // TRACE: Exit point logging
            logger.trace("Exiting processPayment() - transactionId: {}", transactionId);
            
            return transactionId;
            
        } catch (Exception e) {
            // ERROR: Log exceptions with full stack trace
            logger.error("Payment processing failed for user: {}, amount: {} {}",
                userId, amount, currency, e);
            throw e;
        }
    }
    
    /*
     * Refund a payment.
     * @param transactionId Original transaction ID
     * @param reason Refund reason
     * @return Refund transaction ID
     */
    public String refundPayment(String transactionId, String reason) {
        logger.trace("Entering refundPayment() - transactionId: {}", transactionId);
        
        logger.info("Processing refund for transaction: {}, reason: {}", 
            transactionId, reason);
        
        // DEBUG: Check if refund is allowed
        if (logger.isDebugEnabled()) {
            logger.debug("Checking refund eligibility for transaction: {}", transactionId);
            // Expensive operation only done when DEBUG is enabled
            String details = getTransactionDetails(transactionId);
            logger.debug("Transaction details: {}", details);
        }
        
        String refundId = "REFUND-" + transactionId;
        
        logger.info("Refund processed. Refund ID: {}, Original Transaction: {}", 
            refundId, transactionId);
        
        return refundId;
    }
    
    /*
     * Check account balance.
     * @param userId User ID
     * @return Account balance
     */
    public BigDecimal getBalance(String userId) {
        logger.debug("Fetching balance for user: {}", userId);
        
        try {
            // Simulate balance fetch
            BigDecimal balance = new BigDecimal("1500.00");
            
            // TRACE: Include detailed return values
            if (logger.isTraceEnabled()) {
                logger.trace("Balance for user {}: {}", userId, balance);
            }
            
            return balance;
            
        } catch (Exception e) {
            logger.error("Failed to fetch balance for user: {}", userId, e);
            throw e;
        }
    }
    
    /*
     * Process batch payments.
     * @param payments Array of payment requests
     */
    public void processBatchPayments(PaymentRequest[] payments) {
        logger.info("Starting batch payment processing. Total payments: {}", payments.length);
        
        int successful = 0;
        int failed = 0;
        
        for (int i = 0; i < payments.length; i++) {
            PaymentRequest payment = payments[i];
            
            logger.debug("Processing payment {}/{}: userId={}, amount={}", 
                i + 1, payments.length, payment.getUserId(), payment.getAmount());
            
            try {
                processPayment(payment.getUserId(), payment.getAmount(), payment.getCurrency());
                successful++;
            } catch (Exception e) {
                failed++;
                logger.warn("Payment {} failed for user {}: {}", 
                    i + 1, payment.getUserId(), e.getMessage());
            }
        }
        
        logger.info("Batch payment completed. Successful: {}, Failed: {}, Total: {}",
            successful, failed, payments.length);
        
        if (failed > 0) {
            logger.warn("Batch payment had {} failures out of {} payments", 
                failed, payments.length);
        }
    }
    
    // Helper methods
    
    private String generateTransactionId(String userId, BigDecimal amount) {
        logger.trace("Generating transaction ID for user: {}", userId);
        return "TXN-" + System.currentTimeMillis() + "-" + userId.hashCode();
    }
    
    private String getTransactionDetails(String transactionId) {
        // Simulate expensive operation
        return "Details for " + transactionId;
    }
    
    // Inner class for batch processing
    public static class PaymentRequest {
        private String userId;
        private BigDecimal amount;
        private String currency;
        
        public PaymentRequest(String userId, BigDecimal amount, String currency) {
            this.userId = userId;
            this.amount = amount;
            this.currency = currency;
        }
        
        public String getUserId() { return userId; }
        public BigDecimal getAmount() { return amount; }
        public String getCurrency() { return currency; }
    }
}
