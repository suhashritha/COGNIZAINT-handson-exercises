package com.testing.junit;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/*
 * AAA Pattern (Arrange-Act-Assert) Exercise.
 * EXERCISE 4: AAA PATTERN
 * =======================
 * The AAA Pattern is a common approach for structuring unit tests:
 * 1. ARRANGE: Set up the test fixtures, create objects,
 *    and prepare the data needed for the test.
 * 2. ACT: Execute the behavior being tested,
 *    typically calling a single method.
 * 3. ASSERT: Verify that the expected outcome occurred,
 *    checking return values or state changes.
 * Benefits of AAA Pattern:
 * - Clear structure makes tests readable
 * - Easy to identify test purpose
 * - Separates setup from verification
 * - Promotes single responsibility in tests
 */
@DisplayName("AAA Pattern Exercise")
class AAAPatternExerciseTest {
    
    // =========================================
    // Example 1: Simple Calculator Test
    // =========================================
    
    @Test
    @DisplayName("Test Addition using AAA Pattern")
    void testAddition_WithAAA() {
        // ============ ARRANGE ============
        // Set up test fixtures and inputs
        Calculator calculator = new Calculator();
        int firstNumber = 10;
        int secondNumber = 5;
        int expectedSum = 15;
        
        // ============ ACT ============
        // Execute the method under test
        int actualSum = calculator.add(firstNumber, secondNumber);
        
        // ============ ASSERT ============
        // Verify the expected outcome
        assertEquals(expectedSum, actualSum, 
            "Sum of " + firstNumber + " and " + secondNumber + 
            " should equal " + expectedSum);
    }
    
    // =========================================
    // Example 2: Testing Exception Handling
    // =========================================
    
    @Test
    @DisplayName("Test Division by Zero using AAA Pattern")
    void testDivisionByZero_WithAAA() {
        // ============ ARRANGE ============
        Calculator calculator = new Calculator();
        int dividend = 100;
        int divisor = 0;
        
        // ============ ACT & ASSERT ============
        // For exceptions, Act and Assert are combined
        ArithmeticException exception = assertThrows(
            ArithmeticException.class,
            () -> calculator.divide(dividend, divisor)
        );
        
        // Additional assertions on the exception
        assertTrue(exception.getMessage().contains("divide by zero"));
    }
    
    // =========================================
    // Example 3: Testing with Dependencies
    // =========================================
    
    @Test
    @DisplayName("Test Factorial Calculation using AAA Pattern")
    void testFactorial_WithAAA() {
        // ============ ARRANGE ============
        Calculator calculator = new Calculator();
        int input = 5;
        long expectedFactorial = 120; // 5! = 5 * 4 * 3 * 2 * 1 = 120
        
        // ============ ACT ============
        long actualFactorial = calculator.factorial(input);
        
        // ============ ASSERT ============
        assertEquals(expectedFactorial, actualFactorial,
            "Factorial of " + input + " should be " + expectedFactorial);
    }
    
    // =========================================
    // Example 4: Testing Boolean Returns
    // =========================================
    
    @Test
    @DisplayName("Test Prime Number Check using AAA Pattern")
    void testIsPrime_WithAAA() {
        // ============ ARRANGE ============
        Calculator calculator = new Calculator();
        int primeNumber = 17;
        int compositeNumber = 15;
        
        // ============ ACT ============
        boolean isPrime17 = calculator.isPrime(primeNumber);
        boolean isPrime15 = calculator.isPrime(compositeNumber);
        
        // ============ ASSERT ============
        assertTrue(isPrime17, primeNumber + " should be prime");
        assertFalse(isPrime15, compositeNumber + " should not be prime");
    }
    
    // =========================================
    // Example 5: Testing Multiple Scenarios
    // =========================================
    
    @Test
    @DisplayName("Test Even/Odd Check using AAA Pattern")
    void testIsEven_WithAAA() {
        // ============ ARRANGE ============
        Calculator calculator = new Calculator();
        int[] evenNumbers = {0, 2, 4, 100, -2};
        int[] oddNumbers = {1, 3, 5, 99, -1};
        
        // ============ ACT & ASSERT ============
        // Test all even numbers
        for (int num : evenNumbers) {
            // ACT
            boolean result = calculator.isEven(num);
            // ASSERT
            assertTrue(result, num + " should be even");
        }
        
        // Test all odd numbers
        for (int num : oddNumbers) {
            // ACT
            boolean result = calculator.isEven(num);
            // ASSERT
            assertFalse(result, num + " should be odd");
        }
    }
    
    // =========================================
    // Example 6: Complete Test with Comments
    // =========================================
    
    @Test
    @DisplayName("Test Power Calculation with AAA Pattern (Documented)")
    void testPower_WithDocumentedAAA() {
        /*
         * ============================================
         * ARRANGE Phase
         * ============================================
         * Purpose: Prepare test data and objects
         * - Create instances needed for the test
         * - Define input values
         * - Define expected output values
         */
        Calculator calculator = new Calculator();
        double base = 2.0;
        int exponent = 10;
        double expectedResult = 1024.0; // 2^10 = 1024
        double delta = 0.001; // Tolerance for floating point comparison
        
        /*
         * ============================================
         * ACT Phase
         * ============================================
         * Purpose: Execute the method under test
         * - Call exactly ONE method (usually)
         * - Store the result for assertion
         */
        double actualResult = calculator.power(base, exponent);
        
        /*
         * ============================================
         * ASSERT Phase
         * ============================================
         * Purpose: Verify the expected outcome
         * - Compare actual vs expected values
         * - Check state changes if any
         * - Verify exception throwing if expected
         */
        assertEquals(expectedResult, actualResult, delta,
            "Power calculation: " + base + "^" + exponent + 
            " should equal " + expectedResult);
    }
    
    // =========================================
    // Example 7: Nested Tests with AAA
    // =========================================
    
    @Nested
    @DisplayName("Subtraction Tests using AAA Pattern")
    class SubtractionTests {
        
        private Calculator calculator;
        
        @BeforeEach
        void setUp() {
            // Common ARRANGE for all tests in this class
            calculator = new Calculator();
        }
        
        @Test
        @DisplayName("Subtract positive numbers")
        void testSubtractPositives() {
            // ARRANGE (specific to this test)
            int a = 10, b = 3;
            int expected = 7;
            
            // ACT
            int result = calculator.subtract(a, b);
            
            // ASSERT
            assertEquals(expected, result);
        }
        
        @Test
        @DisplayName("Subtract with negative result")
        void testSubtractNegativeResult() {
            // ARRANGE
            int a = 5, b = 10;
            int expected = -5;
            
            // ACT
            int result = calculator.subtract(a, b);
            
            // ASSERT
            assertEquals(expected, result);
        }
        
        @Test
        @DisplayName("Subtract from zero")
        void testSubtractFromZero() {
            // ARRANGE
            int a = 0, b = 5;
            int expected = -5;
            
            // ACT
            int result = calculator.subtract(a, b);
            
            // ASSERT
            assertEquals(expected, result);
        }
    }
    
    // =========================================
    // Example 8: Using assertAll with AAA
    // =========================================
    
    @Test
    @DisplayName("Multiple Operations with assertAll using AAA")
    void testMultipleOperations_WithAssertAll() {
        // ============ ARRANGE ============
        Calculator calculator = new Calculator();
        int a = 10, b = 5;
        
        // ============ ACT ============
        int sum = calculator.add(a, b);
        int difference = calculator.subtract(a, b);
        int product = calculator.multiply(a, b);
        int quotient = calculator.divide(a, b);
        
        // ============ ASSERT ============
        assertAll("All calculator operations",
            () -> assertEquals(15, sum, "10 + 5 = 15"),
            () -> assertEquals(5, difference, "10 - 5 = 5"),
            () -> assertEquals(50, product, "10 * 5 = 50"),
            () -> assertEquals(2, quotient, "10 / 5 = 2")
        );
    }
}
