package com.testing.mockito;

import java.time.LocalDateTime;

/*
 * User entity class.
 */
public class User {
    
    private Long id;
    private String name;
    private String email;
    private boolean active;
    private LocalDateTime createdAt;
    
    // Default constructor
    public User() {
        this.createdAt = LocalDateTime.now();
        this.active = true;
    }
    
    // Constructor with name and email
    public User(String name, String email) {
        this();
        this.name = name;
        this.email = email;
    }
    
    // Full constructor
    public User(Long id, String name, String email) {
        this(name, email);
        this.id = id;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isActive() {
        return active;
    }
    
    public void setActive(boolean active) {
        this.active = active;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", active=" + active +
                '}';
    }
}
