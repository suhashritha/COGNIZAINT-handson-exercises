package com.testing.mockito;

/*
 * User Service - Business logic that depends on UserRepository.
 * This service will be tested using Mockito to mock the repository.
 */
public class UserService {
    
    private final UserRepository userRepository;
    
    /*
     * Constructor with dependency injection.
     * @param userRepository Repository dependency
     */
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    /*
     * Get user by ID.
     * @param id User ID
     * @return User object
     * @throws UserNotFoundException if user not found
     */
    public User getUserById(Long id) {
        User user = userRepository.findById(id);
        if (user == null) {
            throw new UserNotFoundException("User not found with ID: " + id);
        }
        return user;
    }
    
    /*
     * Get user by email.
     * @param email User email
     * @return User object
     * @throws UserNotFoundException if user not found
     */
    public User getUserByEmail(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException("User not found with email: " + email);
        }
        return user;
    }
    
    /*
     * Create a new user.
     * @param name User name
     * @param email User email
     * @return Created user
     * @throws IllegalArgumentException if email already exists
     */
    public User createUser(String name, String email) {
        // Check if email already exists
        User existing = userRepository.findByEmail(email);
        if (existing != null) {
            throw new IllegalArgumentException("Email already registered: " + email);
        }
        
        User user = new User(name, email);
        return userRepository.save(user);
    }
    
    /*
     * Update user details.
     * @param id User ID
     * @param name New name
     * @param email New email
     * @return Updated user
     */
    public User updateUser(Long id, String name, String email) {
        User user = getUserById(id);
        user.setName(name);
        user.setEmail(email);
        return userRepository.save(user);
    }
    
    /*
     * Delete user by ID.
     * @param id User ID
     * @throws UserNotFoundException if user not found
     */
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new UserNotFoundException("User not found with ID: " + id);
        }
        userRepository.deleteById(id);
    }
    
    /*
     * Deactivate a user.
     * @param id User ID
     * @return Deactivated user
     */
    public User deactivateUser(Long id) {
        User user = getUserById(id);
        user.setActive(false);
        return userRepository.save(user);
    }
    
    /*
     * Check if user exists.
     * @param id User ID
     * @return true if exists
     */
    public boolean userExists(Long id) {
        return userRepository.existsById(id);
    }
    
    /*
     * Get total user count.
     * @return Number of users
     */
    public long getTotalUsers() {
        return userRepository.count();
    }
}
