package com.testing.mockito;

/*
 * User Repository Interface - to be mocked in tests.
 */
public interface UserRepository {
    
    /*
     * Find user by ID.
     * @param id User ID
     * @return User object or null
     */
    User findById(Long id);
    
    /*
     * Find user by email.
     * @param email User email
     * @return User object or null
     */
    User findByEmail(String email);
    
    /*
     * Save a user to the database.
     * @param user User to save
     * @return Saved user with generated ID
     */
    User save(User user);
    
    /*
     * Delete a user by ID.
     * @param id User ID
     */
    void deleteById(Long id);
    
    /*
     * Check if user exists.
     * @param id User ID
     * @return true if exists
     */
    boolean existsById(Long id);
    
    /*
     * Count total users.
     * @return User count
     */
    long count();
}
