package com.testing.mockito;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/*
 * Mockito Exercise 1: Mocking and Stubbing.
 * EXERCISE 1: MOCKING & STUBBING
 * ==============================
 * This exercise demonstrates:
 * - Creating mock objects with @Mock
 * - Injecting mocks with @InjectMocks
 * - Stubbing method calls with when().thenReturn()
 * - Stubbing void methods with doNothing(), doThrow()
 * - Stubbing exceptions with when().thenThrow()
 * - Argument matchers (any(), eq(), etc.)
 * - Multiple stubbing (thenReturn chaining)
 * Mockito Annotations:
 * -------------------
 * @Mock - Creates a mock object
 * @InjectMocks - Creates object and injects mocks
 * @Spy - Partial mock (real object with some stubbed methods)
 * @Captor - Captures arguments for verification
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Mockito Mocking & Stubbing Exercise")
class MockingAndStubbingTest {
    
    // Mock the repository dependency
    @Mock
    private UserRepository userRepository;
    
    // Inject mock into service
    @InjectMocks
    private UserService userService;
    
    // Test data
    private User testUser;
    
    @BeforeEach
    void setUp() {
        testUser = new User(1L, "John Doe", "john@example.com");
    }
    
    // =========================================
    // Basic Mocking with when().thenReturn()
    // =========================================
    
    @Test
    @DisplayName("Test basic stubbing with when().thenReturn()")
    void testBasicStubbing() {
        // ARRANGE: Stub the mock
        when(userRepository.findById(1L)).thenReturn(testUser);
        
        // ACT: Call the service method
        User result = userService.getUserById(1L);
        
        // ASSERT: Verify the result
        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        assertEquals("john@example.com", result.getEmail());
    }
    
    @Test
    @DisplayName("Test stubbing returns null")
    void testStubbingReturnsNull() {
        // ARRANGE: Stub to return null
        when(userRepository.findById(999L)).thenReturn(null);
        
        // ACT & ASSERT: Should throw exception
        assertThrows(UserNotFoundException.class, 
            () -> userService.getUserById(999L));
    }
    
    // =========================================
    // Stubbing with Argument Matchers
    // =========================================
    
    @Test
    @DisplayName("Test stubbing with any() matcher")
    void testStubbingWithAnyMatcher() {
        // ARRANGE: Stub for any Long argument
        when(userRepository.findById(anyLong())).thenReturn(testUser);
        
        // ACT: Call with different IDs
        User result1 = userService.getUserById(1L);
        User result2 = userService.getUserById(100L);
        User result3 = userService.getUserById(999L);
        
        // ASSERT: All should return the same stubbed user
        assertEquals("John Doe", result1.getName());
        assertEquals("John Doe", result2.getName());
        assertEquals("John Doe", result3.getName());
    }
    
    @Test
    @DisplayName("Test stubbing with String matcher")
    void testStubbingWithStringMatcher() {
        // ARRANGE: Stub for any string email
        when(userRepository.findByEmail(anyString())).thenReturn(testUser);
        
        // ACT
        User result = userService.getUserByEmail("any@email.com");
        
        // ASSERT
        assertNotNull(result);
    }
    
    @Test
    @DisplayName("Test stubbing with eq() matcher")
    void testStubbingWithEqMatcher() {
        // ARRANGE: Use eq() for specific value matching
        when(userRepository.findByEmail(eq("john@example.com"))).thenReturn(testUser);
        when(userRepository.findByEmail(eq("jane@example.com"))).thenReturn(
            new User(2L, "Jane Doe", "jane@example.com"));
        
        // ACT
        User john = userService.getUserByEmail("john@example.com");
        User jane = userService.getUserByEmail("jane@example.com");
        
        // ASSERT
        assertEquals("John Doe", john.getName());
        assertEquals("Jane Doe", jane.getName());
    }
    
    // =========================================
    // Stubbing to Throw Exceptions
    // =========================================
    
    @Test
    @DisplayName("Test stubbing to throw exception")
    void testStubbingThrowsException() {
        // ARRANGE: Stub to throw exception
        when(userRepository.findById(1L))
            .thenThrow(new RuntimeException("Database connection failed"));
        
        // ACT & ASSERT
        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> userService.getUserById(1L));
        
        assertTrue(exception.getMessage().contains("Database connection failed"));
    }
    
    // =========================================
    // Stubbing Void Methods
    // =========================================
    
    @Test
    @DisplayName("Test stubbing void methods with doNothing()")
    void testStubbingVoidMethod() {
        // ARRANGE: Stub existsById and deleteById
        when(userRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRepository).deleteById(1L);
        
        // ACT: Should not throw
        assertDoesNotThrow(() -> userService.deleteUser(1L));
    }
    
    @Test
    @DisplayName("Test stubbing void method to throw exception")
    void testStubbingVoidMethodThrows() {
        // ARRANGE
        when(userRepository.existsById(1L)).thenReturn(true);
        doThrow(new RuntimeException("Delete failed"))
            .when(userRepository).deleteById(1L);
        
        // ACT & ASSERT
        assertThrows(RuntimeException.class, 
            () -> userService.deleteUser(1L));
    }
    
    // =========================================
    // Multiple Return Values (Consecutive Calls)
    // =========================================
    
    @Test
    @DisplayName("Test consecutive stubbing calls")
    void testConsecutiveCalls() {
        // ARRANGE: Different returns for consecutive calls
        when(userRepository.count())
            .thenReturn(5L)    // First call
            .thenReturn(10L)   // Second call
            .thenReturn(15L);  // Third and subsequent calls
        
        // ACT & ASSERT
        assertEquals(5L, userService.getTotalUsers());
        assertEquals(10L, userService.getTotalUsers());
        assertEquals(15L, userService.getTotalUsers());
        assertEquals(15L, userService.getTotalUsers()); // Same as third
    }
    
    // =========================================
    // Stubbing with thenAnswer (Dynamic Response)
    // =========================================
    
    @Test
    @DisplayName("Test dynamic stubbing with thenAnswer()")
    void testDynamicStubbing() {
        // ARRANGE: Return dynamic response based on input
        when(userRepository.findById(anyLong())).thenAnswer(invocation -> {
            Long id = invocation.getArgument(0);
            return new User(id, "User " + id, "user" + id + "@example.com");
        });
        
        // ACT
        User user1 = userService.getUserById(1L);
        User user5 = userService.getUserById(5L);
        
        // ASSERT
        assertEquals("User 1", user1.getName());
        assertEquals("user1@example.com", user1.getEmail());
        assertEquals("User 5", user5.getName());
        assertEquals("user5@example.com", user5.getEmail());
    }
    
    // =========================================
    // Stubbing Save Method
    // =========================================
    
    @Test
    @DisplayName("Test stubbing save method")
    void testStubbingSaveMethod() {
        // ARRANGE
        when(userRepository.findByEmail(anyString())).thenReturn(null); // No existing user
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            user.setId(100L); // Simulate ID generation
            return user;
        });
        
        // ACT
        User createdUser = userService.createUser("New User", "new@example.com");
        
        // ASSERT
        assertNotNull(createdUser);
        assertEquals(100L, createdUser.getId());
        assertEquals("New User", createdUser.getName());
    }
    
    // =========================================
    // Stubbing Boolean Methods
    // =========================================
    
    @Test
    @DisplayName("Test stubbing boolean method")
    void testStubbingBooleanMethod() {
        // ARRANGE
        when(userRepository.existsById(1L)).thenReturn(true);
        when(userRepository.existsById(999L)).thenReturn(false);
        
        // ACT & ASSERT
        assertTrue(userService.userExists(1L));
        assertFalse(userService.userExists(999L));
    }
}
