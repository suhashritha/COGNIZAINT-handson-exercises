package com.cognizant.countryservice.config;

import com.cognizant.countryservice.model.Country;
import com.cognizant.countryservice.model.User;
import com.cognizant.countryservice.repository.CountryRepository;
import com.cognizant.countryservice.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Set;

/*
 * Data Initializer - Loads sample data on startup.
 */
@Component
public class DataInitializer implements CommandLineRunner {
    
    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);
    
    @Autowired
    private CountryRepository countryRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) {
        // Initialize countries
        if (countryRepository.count() == 0) {
            logger.info("Initializing sample countries...");
            countryRepository.save(new Country("IN", "India"));
            countryRepository.save(new Country("US", "United States"));
            countryRepository.save(new Country("UK", "United Kingdom"));
            countryRepository.save(new Country("CA", "Canada"));
            countryRepository.save(new Country("AU", "Australia"));
            countryRepository.save(new Country("DE", "Germany"));
            countryRepository.save(new Country("FR", "France"));
            countryRepository.save(new Country("JP", "Japan"));
            countryRepository.save(new Country("CN", "China"));
            countryRepository.save(new Country("BR", "Brazil"));
            logger.info("Sample countries initialized!");
        }
        
        // Initialize admin user
        if (!userRepository.existsByUsername("admin")) {
            logger.info("Creating admin user...");
            User admin = new User(
                    "admin",
                    passwordEncoder.encode("admin123"),
                    "admin@example.com",
                    Set.of("USER", "ADMIN")
            );
            userRepository.save(admin);
            logger.info("Admin user created (username: admin, password: admin123)");
        }
        
        // Initialize test user
        if (!userRepository.existsByUsername("user")) {
            logger.info("Creating test user...");
            User user = new User(
                    "user",
                    passwordEncoder.encode("user123"),
                    "user@example.com",
                    Set.of("USER")
            );
            userRepository.save(user);
            logger.info("Test user created (username: user, password: user123)");
        }
    }
}
