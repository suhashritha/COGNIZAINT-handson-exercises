package com.cognizant.countryservice.controller;

import com.cognizant.countryservice.dto.*;
import com.cognizant.countryservice.model.User;
import com.cognizant.countryservice.repository.UserRepository;
import com.cognizant.countryservice.security.CustomUserDetailsService;
import com.cognizant.countryservice.security.JwtUtil;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

/*
 * Authentication Controller - JWT Login and Registration.
 * JWT HANDS-ON: AUTHENTICATION ENDPOINTS
 * =======================================
 * Endpoints:
 * - POST /api/auth/register - Register new user
 * - POST /api/auth/login    - Login and get JWT token
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private CustomUserDetailsService userDetailsService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtUtil jwtUtil;
    
    /*
     * POST /api/auth/register - Register a new user.
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Username already exists"));
        }
        
        User user = new User(
                request.getUsername(),
                passwordEncoder.encode(request.getPassword()),
                request.getEmail(),
                Set.of("USER")
        );
        
        userRepository.save(user);
        
        return ResponseEntity.ok(new MessageResponse("User registered successfully"));
    }
    
    /*
     * POST /api/auth/login - Authenticate and get JWT token.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.getUsername(),
                            request.getPassword()
                    )
            );
        } catch (BadCredentialsException e) {
            return ResponseEntity.badRequest()
                    .body(new MessageResponse("Invalid username or password"));
        }
        
        final UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
        final String jwt = jwtUtil.generateToken(userDetails);
        
        return ResponseEntity.ok(new JwtResponse(jwt, request.getUsername()));
    }
}
