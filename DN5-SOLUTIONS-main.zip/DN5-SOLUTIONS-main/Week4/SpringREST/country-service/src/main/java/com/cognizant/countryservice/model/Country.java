package com.cognizant.countryservice.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/*
 * Country Entity.
 */
@Entity
@Table(name = "country")
public class Country {
    
    @Id
    @Column(name = "code", length = 2)
    @NotBlank @Size(min = 2, max = 2)
    private String code;
    
    @Column(name = "name", length = 50, nullable = false)
    @NotBlank @Size(max = 50)
    private String name;
    
    public Country() {}
    
    public Country(String code, String name) {
        this.code = code;
        this.name = name;
    }
    
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    @Override
    public String toString() {
        return "Country{code='" + code + "', name='" + name + "'}";
    }
}
