package com.cognizant.countryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * Country Service Application with JWT Authentication.
 * SPRING REST WITH JWT - HANDS-ON SOLUTION
 * =========================================
 * Features:
 * - JWT-based authentication
 * - User registration and login
 * - Protected REST endpoints
 * - Role-based access control (RBAC)
 * - H2 in-memory database
 * Testing Steps:
 * 1. Register: POST /api/auth/register
 * 2. Login: POST /api/auth/login (get JWT token)
 * 3. Access protected endpoints with: Authorization: Bearer <token>
 */
@SpringBootApplication
public class CountryServiceApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(CountryServiceApplication.class, args);
    }
}
