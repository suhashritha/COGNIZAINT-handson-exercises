package com.cognizant.countryservice.controller;

import com.cognizant.countryservice.model.Country;
import com.cognizant.countryservice.repository.CountryRepository;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
 * Country Controller - JWT Protected REST Endpoints.
 * SPRING REST HANDS-ON: CRUD OPERATIONS WITH JWT
 * ===============================================
 * All endpoints require JWT authentication.
 * Endpoints:
 * - GET    /api/countries      - Get all countries
 * - GET    /api/countries/{code} - Get country by code
 * - POST   /api/countries      - Create new country
 * - PUT    /api/countries/{code} - Update country
 * - DELETE /api/countries/{code} - Delete country
 */
@RestController
@RequestMapping("/api/countries")
public class CountryController {
    
    private static final Logger logger = LoggerFactory.getLogger(CountryController.class);
    
    @Autowired
    private CountryRepository countryRepository;
    
    /*
     * GET /api/countries - Get all countries (requires authentication).
     */
    @GetMapping
    public ResponseEntity<List<Country>> getAllCountries() {
        logger.info("Fetching all countries");
        List<Country> countries = countryRepository.findAllByOrderByNameAsc();
        return ResponseEntity.ok(countries);
    }
    
    /*
     * GET /api/countries/{code} - Get country by code.
     */
    @GetMapping("/{code}")
    public ResponseEntity<Country> getCountryByCode(@PathVariable String code) {
        logger.info("Fetching country with code: {}", code);
        return countryRepository.findById(code.toUpperCase())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * GET /api/countries/search?name=xxx - Search countries by name.
     */
    @GetMapping("/search")
    public ResponseEntity<List<Country>> searchCountries(@RequestParam String name) {
        logger.info("Searching countries with name containing: {}", name);
        List<Country> countries = countryRepository.findByNameContainingIgnoreCase(name);
        return ResponseEntity.ok(countries);
    }
    
    /*
     * POST /api/countries - Create new country (requires ADMIN role).
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createCountry(@Valid @RequestBody Country country) {
        logger.info("Creating country: {}", country.getCode());
        
        if (countryRepository.existsById(country.getCode())) {
            return ResponseEntity.badRequest()
                    .body("Country with code " + country.getCode() + " already exists");
        }
        
        country.setCode(country.getCode().toUpperCase());
        Country saved = countryRepository.save(country);
        return ResponseEntity.ok(saved);
    }
    
    /*
     * PUT /api/countries/{code} - Update existing country.
     */
    @PutMapping("/{code}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> updateCountry(@PathVariable String code, 
                                           @Valid @RequestBody Country country) {
        logger.info("Updating country: {}", code);
        
        return countryRepository.findById(code.toUpperCase())
                .map(existing -> {
                    existing.setName(country.getName());
                    Country updated = countryRepository.save(existing);
                    return ResponseEntity.ok(updated);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * DELETE /api/countries/{code} - Delete country.
     */
    @DeleteMapping("/{code}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteCountry(@PathVariable String code) {
        logger.info("Deleting country: {}", code);
        
        return countryRepository.findById(code.toUpperCase())
                .map(country -> {
                    countryRepository.delete(country);
                    return ResponseEntity.ok().body("Country deleted successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
