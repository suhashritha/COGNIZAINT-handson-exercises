package com.cognizant.ormlearn.repository;

import com.cognizant.ormlearn.model.Country;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/*
 * CountryRepository - Spring Data JPA Repository.
 * SPRING DATA JPA HANDS-ON: REPOSITORY INTERFACE
 * ===============================================
 * By extending JpaRepository, we get:
 * - save(entity): Create/Update
 * - findById(id): Read by ID
 * - findAll(): Read all
 * - deleteById(id): Delete by ID
 * - count(): Count records
 * - existsById(id): Check existence
 * Query Method Conventions:
 * - findBy[Property]: Find by property
 * - findBy[Property]Containing: LIKE %value%
 * - findBy[Property]IgnoreCase: Case insensitive
 * - findBy[Property]OrderBy[Property]: With sorting
 */
@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
    
    /*
     * Find country by name (exact match, case-insensitive).
     * @param name Country name
     * @return Optional containing country if found
     */
    Optional<Country> findByNameIgnoreCase(String name);
    
    /*
     * Find countries by name containing keyword.
     * @param keyword Keyword to search
     * @return List of matching countries
     */
    List<Country> findByNameContainingIgnoreCase(String keyword);
    
    /*
     * Find countries with name starting with prefix.
     * @param prefix Name prefix
     * @return List of matching countries
     */
    List<Country> findByNameStartingWithIgnoreCase(String prefix);
    
    /*
     * Find all countries ordered by name.
     * @return Sorted list of countries
     */
    List<Country> findAllByOrderByNameAsc();
    
    /*
     * Custom JPQL Query - Find countries by name pattern.
     * @param pattern Name pattern
     * @return List of matching countries
     */
    @Query("SELECT c FROM Country c WHERE LOWER(c.name) LIKE LOWER(CONCAT('%', :pattern, '%'))")
    List<Country> searchByName(@Param("pattern") String pattern);
    
    /*
     * Native SQL Query - Get all country codes.
     * @return List of country codes
     */
    @Query(value = "SELECT co_code FROM country ORDER BY co_code", nativeQuery = true)
    List<String> findAllCodes();
    
    /*
     * Native SQL Query - Count countries by name pattern.
     * @param pattern Name pattern
     * @return Count of matching countries
     */
    @Query(value = "SELECT COUNT(*) FROM country WHERE co_name LIKE %:pattern%", nativeQuery = true)
    long countByNamePattern(@Param("pattern") String pattern);
    
    /*
     * Check if country exists by name.
     * @param name Country name
     * @return true if exists
     */
    boolean existsByNameIgnoreCase(String name);
}
