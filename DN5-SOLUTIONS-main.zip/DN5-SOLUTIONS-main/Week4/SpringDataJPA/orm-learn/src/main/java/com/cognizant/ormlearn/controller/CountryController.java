package com.cognizant.ormlearn.controller;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * CountryController - REST API for Country operations.
 * SPRING DATA JPA HANDS-ON: REST CONTROLLER
 * ==========================================
 * Endpoints:
 * - GET    /api/countries        - Get all countries
 * - GET    /api/countries/{code} - Get country by code
 * - POST   /api/countries        - Add new country
 * - PUT    /api/countries/{code} - Update country
 * - DELETE /api/countries/{code} - Delete country
 * - GET    /api/countries/search - Search countries
 */
@RestController
@RequestMapping("/api/countries")
public class CountryController {
    
    private final CountryService countryService;
    
    @Autowired
    public CountryController(CountryService countryService) {
        this.countryService = countryService;
    }
    
    /*
     * GET /api/countries - Get all countries.
     */
    @GetMapping
    public ResponseEntity<List<Country>> getAllCountries(
            @RequestParam(defaultValue = "false") boolean sorted) {
        List<Country> countries = sorted ? 
            countryService.getAllCountriesSorted() : 
            countryService.getAllCountries();
        return ResponseEntity.ok(countries);
    }
    
    /*
     * GET /api/countries/{code} - Get country by code.
     */
    @GetMapping("/{code}")
    public ResponseEntity<Country> getCountryByCode(@PathVariable String code) {
        return countryService.getCountryByCode(code)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * GET /api/countries/search - Search countries.
     */
    @GetMapping("/search")
    public ResponseEntity<List<Country>> searchCountries(@RequestParam String q) {
        List<Country> countries = countryService.searchCountries(q);
        return ResponseEntity.ok(countries);
    }
    
    /*
     * POST /api/countries - Add new country.
     */
    @PostMapping
    public ResponseEntity<?> addCountry(@Valid @RequestBody Country country) {
        try {
            Country saved = countryService.addCountry(country);
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", e.getMessage()));
        }
    }
    
    /*
     * PUT /api/countries/{code} - Update country.
     */
    @PutMapping("/{code}")
    public ResponseEntity<?> updateCountry(
            @PathVariable String code,
            @Valid @RequestBody Country country) {
        try {
            Country updated = countryService.updateCountry(code, country);
            return ResponseEntity.ok(updated);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    /*
     * DELETE /api/countries/{code} - Delete country.
     */
    @DeleteMapping("/{code}")
    public ResponseEntity<?> deleteCountry(@PathVariable String code) {
        try {
            countryService.deleteCountry(code);
            return ResponseEntity.noContent().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    /*
     * GET /api/countries/stats - Get statistics.
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalCountries", countryService.getCountryCount());
        stats.put("countryCodes", countryService.getAllCountryCodes());
        return ResponseEntity.ok(stats);
    }
}
