package com.cognizant.ormlearn;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.util.List;

/*
 * OrmLearnApplication - Spring Boot Main Application.
 * SPRING DATA JPA HANDS-ON: MAIN APPLICATION
 * ===========================================
 * This application demonstrates:
 * - Spring Data JPA configuration
 * - Entity mapping with annotations
 * - Repository interface with query methods
 * - Service layer with transactions
 * - REST API endpoints
 * To Run:
 * 1. mvn spring-boot:run
 * 2. Access API: http://localhost:8080/api/countries
 * 3. H2 Console: http://localhost:8080/h2-console
 */
@SpringBootApplication
public class OrmLearnApplication {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
    
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
        LOGGER.info("ORM Learn Application Started!");
        
        // Test the application
        CountryService countryService = context.getBean(CountryService.class);
        testGetAllCountries(countryService);
        
        printApiEndpoints();
    }
    
    /*
     * Initialize sample data on startup.
     */
    @Bean
    CommandLineRunner initData(CountryService countryService) {
        return args -> {
            LOGGER.info("Initializing sample country data...");
            
            // Add sample countries
            try {
                countryService.addCountry(new Country("IN", "India"));
                countryService.addCountry(new Country("US", "United States of America"));
                countryService.addCountry(new Country("UK", "United Kingdom"));
                countryService.addCountry(new Country("CA", "Canada"));
                countryService.addCountry(new Country("AU", "Australia"));
                countryService.addCountry(new Country("DE", "Germany"));
                countryService.addCountry(new Country("FR", "France"));
                countryService.addCountry(new Country("JP", "Japan"));
                countryService.addCountry(new Country("CN", "China"));
                countryService.addCountry(new Country("BR", "Brazil"));
                
                LOGGER.info("Sample data initialized: {} countries", 
                    countryService.getCountryCount());
            } catch (Exception e) {
                LOGGER.warn("Error initializing data: {}", e.getMessage());
            }
        };
    }
    
    /*
     * Test method to get all countries.
     */
    private static void testGetAllCountries(CountryService countryService) {
        LOGGER.info("=== Testing getAllCountries ===");
        List<Country> countries = countryService.getAllCountries();
        LOGGER.debug("countries={}", countries);
        LOGGER.info("Total countries: {}", countries.size());
    }
    
    /*
     * Print API endpoints.
     */
    private static void printApiEndpoints() {
        System.out.println("\n================================================");
        System.out.println("ORM LEARN - SPRING DATA JPA DEMO");
        System.out.println("================================================");
        System.out.println("\nREST API Endpoints:");
        System.out.println("  GET    /api/countries           - Get all countries");
        System.out.println("  GET    /api/countries/{code}    - Get by code");
        System.out.println("  GET    /api/countries/search?q= - Search");
        System.out.println("  POST   /api/countries           - Add country");
        System.out.println("  PUT    /api/countries/{code}    - Update");
        System.out.println("  DELETE /api/countries/{code}    - Delete");
        System.out.println("\nH2 Console: http://localhost:8080/h2-console");
        System.out.println("  JDBC URL: jdbc:h2:mem:ormlearn");
        System.out.println("  Username: sa");
        System.out.println("  Password: (empty)");
        System.out.println("================================================\n");
    }
}
