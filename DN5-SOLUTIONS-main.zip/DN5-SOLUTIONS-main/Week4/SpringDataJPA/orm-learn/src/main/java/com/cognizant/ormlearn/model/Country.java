package com.cognizant.ormlearn.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/*
 * Country Entity - Demonstrates JPA Entity Mapping.
 * SPRING DATA JPA HANDS-ON 1: COUNTRY MANAGEMENT
 * ===============================================
 * JPA Annotations Used:
 * - @Entity: Marks class as JPA entity
 * - @Table: Maps to database table
 * - @Id: Primary key
 * - @Column: Maps to column with specifications
 */
@Entity
@Table(name = "country")
public class Country {
    
    @Id
    @Column(name = "co_code", length = 2)
    @NotBlank(message = "Country code is required")
    @Size(min = 2, max = 2, message = "Country code must be exactly 2 characters")
    private String code;
    
    @Column(name = "co_name", length = 50, nullable = false)
    @NotBlank(message = "Country name is required")
    @Size(max = 50, message = "Country name cannot exceed 50 characters")
    private String name;
    
    // Default constructor (required by JPA)
    public Country() {}
    
    // Constructor with all fields
    public Country(String code, String name) {
        this.code = code;
        this.name = name;
    }
    
    // Getters and Setters
    public String getCode() {
        return code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public String toString() {
        return "Country{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Country country = (Country) o;
        return code.equals(country.code);
    }
    
    @Override
    public int hashCode() {
        return code.hashCode();
    }
}
