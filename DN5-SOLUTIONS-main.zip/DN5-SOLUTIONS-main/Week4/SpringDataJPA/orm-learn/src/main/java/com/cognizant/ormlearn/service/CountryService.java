package com.cognizant.ormlearn.service;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/*
 * CountryService - Service Layer for Country operations.
 * SPRING DATA JPA HANDS-ON: SERVICE LAYER
 * ========================================
 * Service Layer responsibilities:
 * - Business logic implementation
 * - Transaction management (@Transactional)
 * - Coordination between repository and controller
 * - Exception handling
 * @Transactional:
 * - Ensures ACID properties
 * - Rollback on runtime exceptions
 * - Default: readOnly=false
 */
@Service
public class CountryService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(CountryService.class);
    
    private final CountryRepository countryRepository;
    
    @Autowired
    public CountryService(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
    }
    
    /*
     * Get all countries.
     * @return List of all countries
     */
    @Transactional(readOnly = true)
    public List<Country> getAllCountries() {
        LOGGER.info("Getting all countries");
        List<Country> countries = countryRepository.findAll();
        LOGGER.debug("Found {} countries", countries.size());
        return countries;
    }
    
    /*
     * Get all countries sorted by name.
     * @return Sorted list of countries
     */
    @Transactional(readOnly = true)
    public List<Country> getAllCountriesSorted() {
        LOGGER.info("Getting all countries sorted by name");
        return countryRepository.findAllByOrderByNameAsc();
    }
    
    /*
     * Get country by code.
     * @param code Country code
     * @return Optional containing country if found
     */
    @Transactional(readOnly = true)
    public Optional<Country> getCountryByCode(String code) {
        LOGGER.info("Getting country by code: {}", code);
        return countryRepository.findById(code.toUpperCase());
    }
    
    /*
     * Get country by name.
     * @param name Country name
     * @return Optional containing country if found
     */
    @Transactional(readOnly = true)
    public Optional<Country> getCountryByName(String name) {
        LOGGER.info("Getting country by name: {}", name);
        return countryRepository.findByNameIgnoreCase(name);
    }
    
    /*
     * Search countries by name keyword.
     * @param keyword Search keyword
     * @return List of matching countries
     */
    @Transactional(readOnly = true)
    public List<Country> searchCountries(String keyword) {
        LOGGER.info("Searching countries with keyword: {}", keyword);
        return countryRepository.searchByName(keyword);
    }
    
    /*
     * Add a new country.
     * @param country Country to add
     * @return Added country
     * @throws IllegalArgumentException if country code already exists
     */
    @Transactional
    public Country addCountry(Country country) {
        LOGGER.info("Adding new country: {}", country.getCode());
        
        // Normalize code to uppercase
        country.setCode(country.getCode().toUpperCase());
        
        // Check if country already exists
        if (countryRepository.existsById(country.getCode())) {
            throw new IllegalArgumentException(
                "Country with code already exists: " + country.getCode());
        }
        
        Country saved = countryRepository.save(country);
        LOGGER.info("Country added successfully: {}", saved);
        return saved;
    }
    
    /*
     * Update an existing country.
     * @param code Country code
     * @param updatedCountry Updated country data
     * @return Updated country
     * @throws IllegalArgumentException if country not found
     */
    @Transactional
    public Country updateCountry(String code, Country updatedCountry) {
        LOGGER.info("Updating country: {}", code);
        
        return countryRepository.findById(code.toUpperCase())
                .map(existing -> {
                    existing.setName(updatedCountry.getName());
                    Country saved = countryRepository.save(existing);
                    LOGGER.info("Country updated successfully: {}", saved);
                    return saved;
                })
                .orElseThrow(() -> new IllegalArgumentException(
                    "Country not found: " + code));
    }
    
    /*
     * Delete a country by code.
     * @param code Country code
     * @throws IllegalArgumentException if country not found
     */
    @Transactional
    public void deleteCountry(String code) {
        LOGGER.info("Deleting country: {}", code);
        
        if (!countryRepository.existsById(code.toUpperCase())) {
            throw new IllegalArgumentException("Country not found: " + code);
        }
        
        countryRepository.deleteById(code.toUpperCase());
        LOGGER.info("Country deleted successfully: {}", code);
    }
    
    /*
     * Get total count of countries.
     * @return Number of countries
     */
    @Transactional(readOnly = true)
    public long getCountryCount() {
        return countryRepository.count();
    }
    
    /*
     * Check if country exists.
     * @param code Country code
     * @return true if exists
     */
    @Transactional(readOnly = true)
    public boolean countryExists(String code) {
        return countryRepository.existsById(code.toUpperCase());
    }
    
    /*
     * Get all country codes.
     * @return List of country codes
     */
    @Transactional(readOnly = true)
    public List<String> getAllCountryCodes() {
        return countryRepository.findAllCodes();
    }
}
