/*
 * Product class for the E-commerce Platform Search Function.
 * This class represents a product with attributes used for searching.
 */
public class Product implements Comparable<Product> {
    
    private String productId;
    private String productName;
    private String category;
    private double price;
    
    /*
     * Constructor for Product.
     * @param productId Unique identifier for the product
     * @param productName Name of the product
     * @param category Category of the product
     * @param price Price of the product
     */
    public Product(String productId, String productName, String category, double price) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.price = price;
    }
    
    // Getters and Setters
    public String getProductId() {
        return productId;
    }
    
    public void setProductId(String productId) {
        this.productId = productId;
    }
    
    public String getProductName() {
        return productName;
    }
    
    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    /*
     * Compare products by name for sorting (required for binary search).
     */
    @Override
    public int compareTo(Product other) {
        return this.productName.compareToIgnoreCase(other.productName);
    }
    
    @Override
    public String toString() {
        return String.format("Product[ID=%s, Name=%s, Category=%s, Price=$%.2f]",
                productId, productName, category, price);
    }
}
