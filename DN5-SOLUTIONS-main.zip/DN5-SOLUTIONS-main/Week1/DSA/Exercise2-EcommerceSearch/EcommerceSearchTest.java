/*
 * Test class for E-commerce Platform Search Function.
 * This class demonstrates and compares:
 * - Linear Search: O(n) - suitable for unsorted, small datasets
 * - Binary Search: O(log n) - suitable for sorted, large datasets
 * Analysis Summary:
 * =================
 * | Algorithm      | Best Case | Average | Worst Case | Space | Sorted Required |
 * |----------------|-----------|---------|------------|-------|-----------------|
 * | Linear Search  | O(1)      | O(n)    | O(n)       | O(1)  | No              |
 * | Binary Search  | O(1)      | O(log n)| O(log n)   | O(1)  | Yes             |
 * When to use which:
 * - Linear Search: Small datasets, unsorted data, one-time searches
 * - Binary Search: Large datasets, sorted data, frequent searches
 * For an e-commerce platform with millions of products, Binary Search is
 * significantly more efficient for frequent product lookups!
 */
public class EcommerceSearchTest {
    
    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("E-COMMERCE PLATFORM SEARCH FUNCTION");
        System.out.println("DSA Exercise 2 - Search Algorithms");
        System.out.println("================================================\n");
        
        // Create sample products
        Product[] products = {
            new Product("P001", "Laptop", "Electronics", 999.99),
            new Product("P002", "Smartphone", "Electronics", 699.99),
            new Product("P003", "Headphones", "Electronics", 199.99),
            new Product("P004", "Keyboard", "Accessories", 79.99),
            new Product("P005", "Mouse", "Accessories", 29.99),
            new Product("P006", "Monitor", "Electronics", 399.99),
            new Product("P007", "Desk Chair", "Furniture", 249.99),
            new Product("P008", "USB Cable", "Accessories", 9.99),
            new Product("P009", "Webcam", "Electronics", 89.99),
            new Product("P010", "Tablet", "Electronics", 449.99),
            new Product("P011", "Apple Watch", "Electronics", 399.99),
            new Product("P012", "Backpack", "Accessories", 59.99),
            new Product("P013", "Charger", "Accessories", 24.99),
            new Product("P014", "Desk Lamp", "Furniture", 34.99),
            new Product("P015", "External SSD", "Electronics", 129.99)
        };
        
        SearchAlgorithms searchAlgo = new SearchAlgorithms();
        
        // Display all products
        System.out.println("PRODUCT CATALOG (" + products.length + " products):");
        System.out.println("------------------------------------------------");
        for (Product p : products) {
            System.out.println(p);
        }
        
        // ============================================
        // TEST 1: Linear Search (Unsorted Array)
        // ============================================
        System.out.println("\n================================================");
        System.out.println("TEST 1: LINEAR SEARCH (Unsorted Array)");
        System.out.println("================================================");
        
        String[] searchTerms = {"Webcam", "Laptop", "External SSD", "Gaming Console"};
        
        for (String term : searchTerms) {
            System.out.println("\nSearching for: \"" + term + "\"");
            long startTime = System.nanoTime();
            Product result = searchAlgo.linearSearch(products, term);
            long endTime = System.nanoTime();
            
            if (result != null) {
                System.out.println("Found: " + result);
            } else {
                System.out.println("Product not found!");
            }
            System.out.println("Time taken: " + (endTime - startTime) + " nanoseconds");
        }
        
        // ============================================
        // TEST 2: Binary Search (Sorted Array)
        // ============================================
        System.out.println("\n================================================");
        System.out.println("TEST 2: BINARY SEARCH (Sorted Array)");
        System.out.println("================================================");
        
        // Sort products by name first
        System.out.println("\nSorting products by name...");
        searchAlgo.sortProducts(products);
        
        System.out.println("\nSorted Product List:");
        System.out.println("--------------------");
        for (Product p : products) {
            System.out.println("  " + p.getProductName());
        }
        
        for (String term : searchTerms) {
            System.out.println("\nSearching for: \"" + term + "\"");
            long startTime = System.nanoTime();
            Product result = searchAlgo.binarySearch(products, term);
            long endTime = System.nanoTime();
            
            if (result != null) {
                System.out.println("Found: " + result);
            } else {
                System.out.println("Product not found!");
            }
            System.out.println("Time taken: " + (endTime - startTime) + " nanoseconds");
        }
        
        // ============================================
        // TEST 3: Performance Comparison
        // ============================================
        System.out.println("\n================================================");
        System.out.println("TEST 3: PERFORMANCE COMPARISON");
        System.out.println("================================================");
        
        // Create larger dataset for meaningful comparison
        int largeSize = 10000;
        Product[] largeProductArray = new Product[largeSize];
        for (int i = 0; i < largeSize; i++) {
            largeProductArray[i] = new Product(
                "P" + String.format("%05d", i),
                "Product" + String.format("%05d", i),
                "Category" + (i % 10),
                Math.random() * 1000
            );
        }
        
        // Sort for binary search
        searchAlgo.sortProducts(largeProductArray);
        
        String targetProduct = "Product09999"; // Last product
        
        System.out.println("\nSearching in " + largeSize + " products for worst-case scenario");
        System.out.println("Target: " + targetProduct);
        
        // Linear Search
        long linearStart = System.nanoTime();
        searchAlgo.linearSearch(largeProductArray, targetProduct);
        long linearEnd = System.nanoTime();
        int linearComparisons = searchAlgo.getComparisons();
        
        // Binary Search
        long binaryStart = System.nanoTime();
        searchAlgo.binarySearch(largeProductArray, targetProduct);
        long binaryEnd = System.nanoTime();
        int binaryComparisons = searchAlgo.getComparisons();
        
        System.out.println("\n+------------------------+------------------+------------------+");
        System.out.println("| Algorithm              | Comparisons      | Time (ns)        |");
        System.out.println("+------------------------+------------------+------------------+");
        System.out.printf("| Linear Search          | %-16d | %-16d |\n", 
            linearComparisons, (linearEnd - linearStart));
        System.out.printf("| Binary Search          | %-16d | %-16d |\n", 
            binaryComparisons, (binaryEnd - binaryStart));
        System.out.println("+------------------------+------------------+------------------+");
        
        System.out.println("\n================================================");
        System.out.println("CONCLUSION");
        System.out.println("================================================");
        System.out.println();
        System.out.println("For an E-commerce platform, BINARY SEARCH is preferred because:");
        System.out.println("1. Products are typically stored sorted (by ID, name, etc.)");
        System.out.println("2. Search operations are very frequent");
        System.out.println("3. Product catalogs can have millions of items");
        System.out.println("4. O(log n) << O(n) for large datasets");
        System.out.println();
        System.out.println("Example: For 1 million products:");
        System.out.println("  - Linear Search: Up to 1,000,000 comparisons");
        System.out.println("  - Binary Search: Up to ~20 comparisons (log₂1000000 ≈ 20)");
        System.out.println();
        System.out.println("That's a 50,000x improvement!");
    }
}
