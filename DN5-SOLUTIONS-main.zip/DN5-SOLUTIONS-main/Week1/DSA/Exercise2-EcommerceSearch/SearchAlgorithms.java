import java.util.Arrays;

/*
 * SearchAlgorithms class implementing Linear and Binary Search.
 * This class demonstrates:
 * - Linear Search: O(n) time complexity
 * - Binary Search: O(log n) time complexity
 * Big O Notation Analysis:
 * ========================
 * LINEAR SEARCH:
 * - Best Case: O(1) - Element found at first position
 * - Average Case: O(n) - Element found in middle
 * - Worst Case: O(n) - Element at last position or not found
 * - Space Complexity: O(1) - No extra space needed
 * BINARY SEARCH:
 * - Best Case: O(1) - Element found at middle
 * - Average Case: O(log n) - Halving search space each iteration
 * - Worst Case: O(log n) - Element at boundary or not found
 * - Space Complexity: O(1) for iterative, O(log n) for recursive
 * - Prerequisite: Array must be SORTED
 */
public class SearchAlgorithms {
    
    private int comparisons; // Track number of comparisons for analysis
    
    /*
     * Linear Search - Searches for a product by name in an unsorted array.
     * Time Complexity: O(n)
     * - Scans each element one by one
     * - No sorting required
     * @param products Array of products to search
     * @param targetName Name of the product to find
     * @return The Product if found, null otherwise
     */
    public Product linearSearch(Product[] products, String targetName) {
        comparisons = 0;
        
        for (Product product : products) {
            comparisons++;
            if (product.getProductName().equalsIgnoreCase(targetName)) {
                System.out.println("Linear Search: Found after " + comparisons + " comparisons");
                return product;
            }
        }
        
        System.out.println("Linear Search: Not found after " + comparisons + " comparisons");
        return null;
    }
    
    /*
     * Binary Search - Searches for a product by name in a SORTED array.
     * Time Complexity: O(log n)
     * - Divides search space in half each iteration
     * - Requires sorted array
     * @param products Sorted array of products to search
     * @param targetName Name of the product to find
     * @return The Product if found, null otherwise
     */
    public Product binarySearch(Product[] products, String targetName) {
        comparisons = 0;
        int left = 0;
        int right = products.length - 1;
        
        while (left <= right) {
            comparisons++;
            int mid = left + (right - left) / 2; // Avoid integer overflow
            
            int comparison = products[mid].getProductName().compareToIgnoreCase(targetName);
            
            if (comparison == 0) {
                System.out.println("Binary Search: Found after " + comparisons + " comparisons");
                return products[mid];
            } else if (comparison < 0) {
                // Target is in the right half
                left = mid + 1;
            } else {
                // Target is in the left half
                right = mid - 1;
            }
        }
        
        System.out.println("Binary Search: Not found after " + comparisons + " comparisons");
        return null;
    }
    
    /*
     * Recursive Binary Search implementation.
     * Time Complexity: O(log n)
     * Space Complexity: O(log n) due to recursive call stack
     * @param products Sorted array of products
     * @param targetName Name to search for
     * @param left Left boundary index
     * @param right Right boundary index
     * @return The Product if found, null otherwise
     */
    public Product binarySearchRecursive(Product[] products, String targetName, int left, int right) {
        if (left > right) {
            return null;
        }
        
        comparisons++;
        int mid = left + (right - left) / 2;
        int comparison = products[mid].getProductName().compareToIgnoreCase(targetName);
        
        if (comparison == 0) {
            return products[mid];
        } else if (comparison < 0) {
            return binarySearchRecursive(products, targetName, mid + 1, right);
        } else {
            return binarySearchRecursive(products, targetName, left, mid - 1);
        }
    }
    
    /*
     * Sorts the product array by name for binary search.
     * Uses Arrays.sort() which implements TimSort - O(n log n).
     * @param products Array to sort
     */
    public void sortProducts(Product[] products) {
        Arrays.sort(products);
    }
    
    /*
     * Gets the number of comparisons from the last search.
     * @return Number of comparisons
     */
    public int getComparisons() {
        return comparisons;
    }
}
