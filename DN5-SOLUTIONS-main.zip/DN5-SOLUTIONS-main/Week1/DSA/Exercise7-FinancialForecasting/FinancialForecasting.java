import java.util.HashMap;
import java.util.Map;

/*
 * Financial Forecasting Tool using Recursive Algorithms.
 * This class demonstrates:
 * - Basic recursion for compound growth calculations
 * - Recursion with memoization for optimization
 * - Time complexity analysis of recursive algorithms
 * Recursion Concepts:
 * ===================
 * 1. Base Case: The condition that stops recursion
 * 2. Recursive Case: The function calls itself with modified parameters
 * 3. Stack: Each recursive call adds a frame to the call stack
 * Time Complexity Analysis:
 * ========================
 * - Simple Recursion: O(n) - one recursive call per year
 * - Fibonacci-style (without memo): O(2^n) - exponential
 * - With Memoization: O(n) - each value computed once
 */
public class FinancialForecasting {
    
    // Memoization cache for optimization
    private Map<Integer, Double> cache = new HashMap<>();
    private int recursiveCalls = 0;
    
    /*
     * Calculates future value using simple recursive approach.
     * Formula: FV = PV * (1 + rate)^years
     * Recursive: FV(n) = FV(n-1) * (1 + rate)
     * Time Complexity: O(n) where n = years
     * Space Complexity: O(n) due to call stack
     * @param presentValue The current value
     * @param growthRate Annual growth rate (e.g., 0.05 for 5%)
     * @param years Number of years to forecast
     * @return The future value
     */
    public double calculateFutureValue(double presentValue, double growthRate, int years) {
        recursiveCalls++;
        
        // Base Case: No more years to compound
        if (years == 0) {
            return presentValue;
        }
        
        // Recursive Case: Apply growth for one year and recurse
        return calculateFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }
    
    /*
     * Calculates future value with memoization for optimization.
     * Memoization stores previously computed values to avoid redundant calculations.
     * Especially useful when the same calculations are repeated.
     * Time Complexity: O(n) - each year computed only once
     * Space Complexity: O(n) for cache + O(n) for call stack
     * @param presentValue The current value
     * @param growthRate Annual growth rate
     * @param years Number of years to forecast
     * @return The future value
     */
    public double calculateFutureValueMemoized(double presentValue, double growthRate, int years) {
        recursiveCalls++;
        
        // Check if already computed
        if (cache.containsKey(years)) {
            return cache.get(years);
        }
        
        // Base Case
        if (years == 0) {
            cache.put(0, presentValue);
            return presentValue;
        }
        
        // Recursive Case with caching
        double result = calculateFutureValueMemoized(presentValue, growthRate, years - 1) * (1 + growthRate);
        cache.put(years, result);
        
        return result;
    }
    
    /*
     * Iterative approach (for comparison).
     * Time Complexity: O(n)
     * Space Complexity: O(1) - no call stack overhead
     * @param presentValue The current value
     * @param growthRate Annual growth rate
     * @param years Number of years
     * @return The future value
     */
    public double calculateFutureValueIterative(double presentValue, double growthRate, int years) {
        double futureValue = presentValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }
    
    /*
     * Calculates future value using tail recursion optimization.
     * Tail recursion can be optimized by compilers to use constant stack space.
     * @param presentValue Current accumulated value
     * @param growthRate Annual growth rate
     * @param years Remaining years
     * @return The future value
     */
    public double calculateFutureValueTailRecursive(double presentValue, double growthRate, int years) {
        recursiveCalls++;
        
        // Base Case
        if (years == 0) {
            return presentValue;
        }
        
        // Tail Recursive Case - computation before recursive call
        return calculateFutureValueTailRecursive(presentValue * (1 + growthRate), growthRate, years - 1);
    }
    
    /*
     * Calculates compound annual growth rate (CAGR) recursively.
     * CAGR = (EndValue / StartValue)^(1/years) - 1
     * @param startValue Initial value
     * @param endValue Final value
     * @param years Number of years
     * @return The CAGR
     */
    public double calculateCAGR(double startValue, double endValue, int years) {
        return Math.pow(endValue / startValue, 1.0 / years) - 1;
    }
    
    /*
     * Forecasts multiple years and returns an array of values.
     * @param presentValue Starting value
     * @param growthRate Annual growth rate
     * @param years Number of years to forecast
     * @return Array of values for each year
     */
    public double[] forecastMultipleYears(double presentValue, double growthRate, int years) {
        double[] forecast = new double[years + 1];
        forecast[0] = presentValue;
        forecastHelper(forecast, growthRate, 1);
        return forecast;
    }
    
    /*
     * Helper method for recursive forecasting.
     */
    private void forecastHelper(double[] forecast, double growthRate, int year) {
        if (year >= forecast.length) {
            return;
        }
        
        forecast[year] = forecast[year - 1] * (1 + growthRate);
        forecastHelper(forecast, growthRate, year + 1);
    }
    
    /*
     * Resets the recursive call counter and cache.
     */
    public void resetCounters() {
        recursiveCalls = 0;
        cache.clear();
    }
    
    /*
     * Gets the number of recursive calls made.
     * @return Number of recursive calls
     */
    public int getRecursiveCalls() {
        return recursiveCalls;
    }
}
