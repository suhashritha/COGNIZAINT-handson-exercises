import java.text.DecimalFormat;

/*
 * Test class for Financial Forecasting Tool.
 * This class demonstrates recursive algorithms for predicting future values
 * based on historical growth rates.
 * Recursion Analysis:
 * ===================
 * How Recursion Simplifies Problems:
 * 1. Break down complex calculations into simple repeated steps
 * 2. Each year's value depends only on the previous year
 * 3. Base case provides the stopping condition
 * Time Complexity:
 * - Simple recursion: O(n)
 * - With memoization: O(n) but faster for repeated calls
 * - Iterative: O(n) with O(1) space
 * Optimization Strategies:
 * 1. Memoization: Store computed values
 * 2. Tail Recursion: Enable compiler optimizations
 * 3. Convert to Iteration: Eliminate stack overhead
 */
public class FinancialForecastingTest {
    
    private static final DecimalFormat CURRENCY_FORMAT = new DecimalFormat("$#,##0.00");
    private static final DecimalFormat PERCENT_FORMAT = new DecimalFormat("0.00%");
    
    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("FINANCIAL FORECASTING TOOL");
        System.out.println("DSA Exercise 7 - Recursive Algorithms");
        System.out.println("================================================\n");
        
        FinancialForecasting forecaster = new FinancialForecasting();
        
        // ============================================
        // TEST 1: Basic Future Value Calculation
        // ============================================
        System.out.println("TEST 1: BASIC FUTURE VALUE CALCULATION");
        System.out.println("========================================");
        System.out.println("Scenario: Investment of $10,000 at 7% annual growth\n");
        
        double presentValue = 10000.0;
        double growthRate = 0.07; // 7%
        int years = 10;
        
        forecaster.resetCounters();
        double futureValue = forecaster.calculateFutureValue(presentValue, growthRate, years);
        
        System.out.println("Present Value: " + CURRENCY_FORMAT.format(presentValue));
        System.out.println("Growth Rate: " + PERCENT_FORMAT.format(growthRate));
        System.out.println("Years: " + years);
        System.out.println("Future Value: " + CURRENCY_FORMAT.format(futureValue));
        System.out.println("Recursive Calls: " + forecaster.getRecursiveCalls());
        
        // ============================================
        // TEST 2: Year-by-Year Forecast
        // ============================================
        System.out.println("\n\nTEST 2: YEAR-BY-YEAR FORECAST");
        System.out.println("========================================");
        
        double[] yearlyForecast = forecaster.forecastMultipleYears(presentValue, growthRate, years);
        
        System.out.println("\n+------+------------------+------------------+");
        System.out.println("| Year | Value            | Growth           |");
        System.out.println("+------+------------------+------------------+");
        
        for (int i = 0; i <= years; i++) {
            String growth = i == 0 ? "N/A" : CURRENCY_FORMAT.format(yearlyForecast[i] - yearlyForecast[i-1]);
            System.out.printf("| %-4d | %-16s | %-16s |\n", 
                i, CURRENCY_FORMAT.format(yearlyForecast[i]), growth);
        }
        System.out.println("+------+------------------+------------------+");
        
        // ============================================
        // TEST 3: Comparison of Methods
        // ============================================
        System.out.println("\n\nTEST 3: COMPARISON OF RECURSIVE VS ITERATIVE");
        System.out.println("==============================================");
        
        // Test with different year ranges
        int[] testYears = {5, 10, 20, 30, 50};
        
        System.out.println("\n+-------+------------------+------------------+------------------+");
        System.out.println("| Years | Recursive Value  | Iterative Value  | Match?           |");
        System.out.println("+-------+------------------+------------------+------------------+");
        
        for (int y : testYears) {
            forecaster.resetCounters();
            double recursive = forecaster.calculateFutureValue(presentValue, growthRate, y);
            double iterative = forecaster.calculateFutureValueIterative(presentValue, growthRate, y);
            boolean match = Math.abs(recursive - iterative) < 0.01;
            
            System.out.printf("| %-5d | %-16s | %-16s | %-16s |\n",
                y, CURRENCY_FORMAT.format(recursive), 
                CURRENCY_FORMAT.format(iterative),
                match ? "✓ Yes" : "✗ No");
        }
        System.out.println("+-------+------------------+------------------+------------------+");
        
        // ============================================
        // TEST 4: Performance Analysis
        // ============================================
        System.out.println("\n\nTEST 4: PERFORMANCE ANALYSIS");
        System.out.println("========================================");
        
        int perfYears = 1000; // Large number to show difference
        
        // Recursive
        forecaster.resetCounters();
        long startRecursive = System.nanoTime();
        double recResult = forecaster.calculateFutureValue(presentValue, growthRate, perfYears);
        long endRecursive = System.nanoTime();
        int recursiveCalls = forecaster.getRecursiveCalls();
        
        // Iterative
        long startIterative = System.nanoTime();
        double iterResult = forecaster.calculateFutureValueIterative(presentValue, growthRate, perfYears);
        long endIterative = System.nanoTime();
        
        System.out.println("Testing with " + perfYears + " years forecast:\n");
        System.out.println("+--------------------+------------------+------------------+");
        System.out.println("| Method             | Time (ns)        | Calls/Iterations |");
        System.out.println("+--------------------+------------------+------------------+");
        System.out.printf("| Recursive          | %-16d | %-16d |\n", 
            (endRecursive - startRecursive), recursiveCalls);
        System.out.printf("| Iterative          | %-16d | %-16d |\n", 
            (endIterative - startIterative), perfYears);
        System.out.println("+--------------------+------------------+------------------+");
        
        // ============================================
        // TEST 5: Different Growth Scenarios
        // ============================================
        System.out.println("\n\nTEST 5: DIFFERENT GROWTH SCENARIOS");
        System.out.println("========================================");
        
        double[] growthRates = {0.03, 0.05, 0.07, 0.10, 0.15};
        int forecastYears = 20;
        
        System.out.println("\nStarting Value: " + CURRENCY_FORMAT.format(presentValue));
        System.out.println("Forecast Period: " + forecastYears + " years\n");
        
        System.out.println("+------------------+------------------+------------------+");
        System.out.println("| Growth Rate      | Future Value     | Total Growth     |");
        System.out.println("+------------------+------------------+------------------+");
        
        for (double rate : growthRates) {
            double fv = forecaster.calculateFutureValueIterative(presentValue, rate, forecastYears);
            double totalGrowth = ((fv - presentValue) / presentValue);
            
            System.out.printf("| %-16s | %-16s | %-16s |\n",
                PERCENT_FORMAT.format(rate),
                CURRENCY_FORMAT.format(fv),
                PERCENT_FORMAT.format(totalGrowth));
        }
        System.out.println("+------------------+------------------+------------------+");
        
        // ============================================
        // TEST 6: Calculate Required Growth Rate (CAGR)
        // ============================================
        System.out.println("\n\nTEST 6: CALCULATE REQUIRED GROWTH RATE (CAGR)");
        System.out.println("==============================================");
        
        double startVal = 10000;
        double targetVal = 50000;
        int targetYears = 15;
        
        double requiredCAGR = forecaster.calculateCAGR(startVal, targetVal, targetYears);
        
        System.out.println("\nGoal: Grow " + CURRENCY_FORMAT.format(startVal) + 
            " to " + CURRENCY_FORMAT.format(targetVal) + " in " + targetYears + " years");
        System.out.println("Required Annual Growth Rate (CAGR): " + PERCENT_FORMAT.format(requiredCAGR));
        
        // Verify
        double verification = forecaster.calculateFutureValueIterative(startVal, requiredCAGR, targetYears);
        System.out.println("Verification: " + CURRENCY_FORMAT.format(verification));
        
        // ============================================
        // SUMMARY
        // ============================================
        System.out.println("\n\n================================================");
        System.out.println("RECURSION ANALYSIS SUMMARY");
        System.out.println("================================================");
        System.out.println();
        System.out.println("Time Complexity of Recursive Future Value:");
        System.out.println("  - T(n) = T(n-1) + O(1)");
        System.out.println("  - T(n) = O(n)");
        System.out.println();
        System.out.println("Space Complexity:");
        System.out.println("  - Recursive: O(n) due to call stack");
        System.out.println("  - Iterative: O(1) constant space");
        System.out.println();
        System.out.println("Optimization Strategies:");
        System.out.println("  1. Use iteration for simple linear recursion");
        System.out.println("  2. Apply memoization for overlapping subproblems");
        System.out.println("  3. Use tail recursion when possible");
        System.out.println("  4. Consider mathematical formulas: FV = PV * (1+r)^n");
        System.out.println();
        System.out.println("When to use Recursion:");
        System.out.println("  - Problems with natural recursive structure");
        System.out.println("  - When code clarity is important");
        System.out.println("  - Tree/graph traversals");
        System.out.println("  - Divide and conquer algorithms");
    }
}
