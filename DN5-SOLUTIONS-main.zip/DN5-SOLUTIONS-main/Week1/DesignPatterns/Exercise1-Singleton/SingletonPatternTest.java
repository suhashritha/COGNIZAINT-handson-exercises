// Testing Singleton Pattern - Logger class
public class SingletonPatternTest {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("SINGLETON PATTERN - LOGGER TEST");
        System.out.println("========================================\n");
        
        // Test 1: Get first instance
        System.out.println("TEST 1: Creating first Logger instance...");
        Logger logger1 = Logger.getInstance();
        System.out.println("Logger1 HashCode: " + logger1.hashCode());
        
        // Test 2: Get second instance
        System.out.println("\nTEST 2: Creating second Logger instance...");
        Logger logger2 = Logger.getInstance();
        System.out.println("Logger2 HashCode: " + logger2.hashCode());
        
        // Test 3: Verify both references point to the same object
        System.out.println("\nTEST 3: Verifying both instances are the same...");
        if (logger1 == logger2) {
            System.out.println("SUCCESS: Both Logger instances are the SAME object!");
            System.out.println("Only ONE instance exists (Singleton Pattern verified)");
        } else {
            System.out.println("FAILURE: Different instances were created!");
        }
        
        // Test 4: Using the Logger
        System.out.println("\n========================================");
        System.out.println("TEST 4: Using the Logger");
        System.out.println("========================================");
        
        logger1.info("Application started");
        logger1.debug("Debug mode enabled");
        logger2.warning("Low memory warning");
        logger2.error("Connection failed");
        
        // Test 5: Multi-threaded test
        System.out.println("\n========================================");
        System.out.println("TEST 5: Multi-threaded Singleton Test");
        System.out.println("========================================");
        
        // Create multiple threads that try to get Logger instance
        Thread thread1 = new Thread(() -> {
            Logger threadLogger = Logger.getInstance();
            System.out.println("Thread 1 - Logger HashCode: " + threadLogger.hashCode());
            threadLogger.info("Message from Thread 1");
        });
        
        Thread thread2 = new Thread(() -> {
            Logger threadLogger = Logger.getInstance();
            System.out.println("Thread 2 - Logger HashCode: " + threadLogger.hashCode());
            threadLogger.info("Message from Thread 2");
        });
        
        Thread thread3 = new Thread(() -> {
            Logger threadLogger = Logger.getInstance();
            System.out.println("Thread 3 - Logger HashCode: " + threadLogger.hashCode());
            threadLogger.info("Message from Thread 3");
        });
        
        // Start all threads
        thread1.start();
        thread2.start();
        thread3.start();
        
        // Wait for threads to complete
        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("\n========================================");
        System.out.println("ALL TESTS COMPLETED");
        System.out.println("========================================");
        System.out.println("\nNote: All hash codes should be identical,");
        System.out.println("proving that only ONE Logger instance exists.");
    }
}
