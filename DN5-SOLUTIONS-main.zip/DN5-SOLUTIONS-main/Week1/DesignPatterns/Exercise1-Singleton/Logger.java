/*
 * Logger - Singleton Pattern Implementation
 * Only one instance exists throughout the app lifecycle
 */
public class Logger {
    
    private static volatile Logger instance;  // volatile for thread safety
    
    public enum LogLevel {
        INFO, DEBUG, WARNING, ERROR
    }
    
    private LogLevel currentLogLevel = LogLevel.INFO;
    
    // private constructor - can't instantiate from outside
    private Logger() {
        System.out.println("Logger instance created.");
    }
    
    // double-checked locking for thread safe singleton
    public static Logger getInstance() {
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }
    
    public void setLogLevel(LogLevel level) {
        this.currentLogLevel = level;
    }
    
    public void info(String message) {
        log(LogLevel.INFO, message);
    }
    
    public void debug(String message) {
        log(LogLevel.DEBUG, message);
    }
    
    public void warning(String message) {
        log(LogLevel.WARNING, message);
    }
    
    public void error(String message) {
        log(LogLevel.ERROR, message);
    }
    
    private void log(LogLevel level, String message) {
        String timestamp = java.time.LocalDateTime.now()
            .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        System.out.println("[" + timestamp + "] [" + level + "] " + message);
    }
}
