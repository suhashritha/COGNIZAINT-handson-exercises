/*
 * WordDocument - Concrete implementation of Document for Word files.
 * This is a Concrete Product in the Factory Method Pattern.
 */
public class WordDocument implements Document {
    
    private String fileName;
    private String content;
    
    /*
     * Constructor for WordDocument.
     */
    public WordDocument() {
        this.fileName = "Untitled.docx";
        this.content = "";
    }
    
    @Override
    public void open() {
        System.out.println("Opening Word Document: " + fileName);
        System.out.println("  - Loading Microsoft Word format (.docx)");
        System.out.println("  - Initializing text editor components");
    }
    
    @Override
    public void save() {
        System.out.println("Saving Word Document: " + fileName);
        System.out.println("  - Compressing document data");
        System.out.println("  - Writing to .docx format");
    }
    
    @Override
    public void close() {
        System.out.println("Closing Word Document: " + fileName);
        System.out.println("  - Releasing resources");
    }
    
    @Override
    public String getType() {
        return "Word Document (.docx)";
    }
    
    /*
     * Word-specific method to add text.
     * @param text The text to add
     */
    public void addText(String text) {
        this.content += text;
        System.out.println("Added text to Word Document");
    }
    
    /*
     * Word-specific method to format text.
     * @param style The style to apply (bold, italic, etc.)
     */
    public void formatText(String style) {
        System.out.println("Applying " + style + " formatting to Word Document");
    }
}
