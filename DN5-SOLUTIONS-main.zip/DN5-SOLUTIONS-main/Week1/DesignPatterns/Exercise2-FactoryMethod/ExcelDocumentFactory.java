/*
 * ExcelDocumentFactory - Concrete Factory for creating Excel documents.
 * This is a Concrete Creator in the Factory Method Pattern.
 * It implements the factory method to create ExcelDocument instances.
 */
public class ExcelDocumentFactory extends DocumentFactory {
    
    /*
     * Factory method implementation for creating Excel documents.
     * @return A new ExcelDocument instance
     */
    @Override
    public Document createDocument() {
        System.out.println("ExcelDocumentFactory: Creating new Excel Document...");
        return new ExcelDocument();
    }
}
