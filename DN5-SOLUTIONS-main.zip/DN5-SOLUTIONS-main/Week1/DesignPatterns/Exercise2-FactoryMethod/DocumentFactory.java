/*
 * DocumentFactory - Abstract Factory class for creating documents.
 * This is the Creator in the Factory Method Pattern.
 * It declares the factory method that returns Document objects.
 * Subclasses will override this method to create specific document types.
 */
public abstract class DocumentFactory {
    
    /*
     * Factory Method - Abstract method to create a document.
     * Subclasses must implement this method to create specific document types.
     * @return A new Document instance
     */
    public abstract Document createDocument();
    
    /*
     * Template method that creates and opens a document.
     * This demonstrates how the factory method can be used in a template pattern.
     * @return An opened Document instance
     */
    public Document createAndOpenDocument() {
        Document document = createDocument();
        document.open();
        return document;
    }
    
    /*
     * Creates a new document with a specific workflow.
     * @param autoSave Whether to enable auto-save
     * @return A configured Document instance
     */
    public Document createDocumentWithConfig(boolean autoSave) {
        Document document = createDocument();
        System.out.println("Creating document of type: " + document.getType());
        document.open();
        if (autoSave) {
            System.out.println("Auto-save enabled for this document");
        }
        return document;
    }
}
