/*
 * PdfDocument - Concrete implementation of Document for PDF files.
 * This is a Concrete Product in the Factory Method Pattern.
 */
public class PdfDocument implements Document {
    
    private String fileName;
    private int pageCount;
    
    /*
     * Constructor for PdfDocument.
     */
    public PdfDocument() {
        this.fileName = "Untitled.pdf";
        this.pageCount = 0;
    }
    
    @Override
    public void open() {
        System.out.println("Opening PDF Document: " + fileName);
        System.out.println("  - Loading Adobe PDF format (.pdf)");
        System.out.println("  - Initializing PDF renderer");
    }
    
    @Override
    public void save() {
        System.out.println("Saving PDF Document: " + fileName);
        System.out.println("  - Generating PDF structure");
        System.out.println("  - Embedding fonts and images");
    }
    
    @Override
    public void close() {
        System.out.println("Closing PDF Document: " + fileName);
        System.out.println("  - Releasing PDF resources");
    }
    
    @Override
    public String getType() {
        return "PDF Document (.pdf)";
    }
    
    /*
     * PDF-specific method to add a page.
     */
    public void addPage() {
        pageCount++;
        System.out.println("Added new page. Total pages: " + pageCount);
    }
    
    /*
     * PDF-specific method to add watermark.
     * @param watermark The watermark text
     */
    public void addWatermark(String watermark) {
        System.out.println("Adding watermark '" + watermark + "' to all pages");
    }
    
    /*
     * PDF-specific method to encrypt document.
     * @param password The encryption password
     */
    public void encrypt(String password) {
        System.out.println("Encrypting PDF document with password protection");
    }
}
