/*
 * Document interface - Base interface for all document types.
 * This is the Product interface in the Factory Method Pattern.
 * All concrete documents must implement this interface.
 */
public interface Document {
    
    /*
     * Opens the document.
     */
    void open();
    
    /*
     * Saves the document.
     */
    void save();
    
    /*
     * Closes the document.
     */
    void close();
    
    /*
     * Gets the document type.
     * @return The type of document
     */
    String getType();
}
