/*
 * WordDocumentFactory - Concrete Factory for creating Word documents.
 * This is a Concrete Creator in the Factory Method Pattern.
 * It implements the factory method to create WordDocument instances.
 */
public class WordDocumentFactory extends DocumentFactory {
    
    /*
     * Factory method implementation for creating Word documents.
     * @return A new WordDocument instance
     */
    @Override
    public Document createDocument() {
        System.out.println("WordDocumentFactory: Creating new Word Document...");
        return new WordDocument();
    }
}
