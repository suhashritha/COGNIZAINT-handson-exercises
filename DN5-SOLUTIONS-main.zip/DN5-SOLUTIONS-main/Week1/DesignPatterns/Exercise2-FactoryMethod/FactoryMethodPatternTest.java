/*
 * Test class to demonstrate the Factory Method Pattern.
 * This class shows how to use the Factory Method Pattern to create
 * different types of documents without knowing their concrete classes.
 * Benefits demonstrated:
 * 1. Decoupling - Client code doesn't need to know concrete classes
 * 2. Single Responsibility - Each factory handles one document type
 * 3. Open/Closed - Easy to add new document types without modifying existing code
 */
public class FactoryMethodPatternTest {
    
    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("FACTORY METHOD PATTERN - DOCUMENT MANAGEMENT TEST");
        System.out.println("================================================\n");
        
        // Create document factories
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        
        // Test 1: Create Word Document
        System.out.println("TEST 1: Creating Word Document");
        System.out.println("--------------------------------");
        Document wordDoc = wordFactory.createDocument();
        System.out.println("Document Type: " + wordDoc.getType());
        wordDoc.open();
        wordDoc.save();
        wordDoc.close();
        
        // Test 2: Create PDF Document
        System.out.println("\nTEST 2: Creating PDF Document");
        System.out.println("--------------------------------");
        Document pdfDoc = pdfFactory.createDocument();
        System.out.println("Document Type: " + pdfDoc.getType());
        pdfDoc.open();
        pdfDoc.save();
        pdfDoc.close();
        
        // Test 3: Create Excel Document
        System.out.println("\nTEST 3: Creating Excel Document");
        System.out.println("--------------------------------");
        Document excelDoc = excelFactory.createDocument();
        System.out.println("Document Type: " + excelDoc.getType());
        excelDoc.open();
        excelDoc.save();
        excelDoc.close();
        
        // Test 4: Using Template Method
        System.out.println("\n================================================");
        System.out.println("TEST 4: Using Template Method (createAndOpenDocument)");
        System.out.println("================================================");
        Document autoOpenedDoc = wordFactory.createAndOpenDocument();
        autoOpenedDoc.save();
        autoOpenedDoc.close();
        
        // Test 5: Dynamic Document Creation
        System.out.println("\n================================================");
        System.out.println("TEST 5: Dynamic Document Creation");
        System.out.println("================================================");
        createDocumentByType("word");
        createDocumentByType("pdf");
        createDocumentByType("excel");
        createDocumentByType("unknown");
        
        // Test 6: Using specific document features
        System.out.println("\n================================================");
        System.out.println("TEST 6: Using Document-Specific Features");
        System.out.println("================================================");
        
        // Word-specific features
        System.out.println("\nWord Document Features:");
        WordDocument word = (WordDocument) wordFactory.createDocument();
        word.open();
        word.addText("Hello World!");
        word.formatText("Bold");
        word.save();
        word.close();
        
        // PDF-specific features
        System.out.println("\nPDF Document Features:");
        PdfDocument pdf = (PdfDocument) pdfFactory.createDocument();
        pdf.open();
        pdf.addPage();
        pdf.addPage();
        pdf.addWatermark("CONFIDENTIAL");
        pdf.encrypt("password123");
        pdf.save();
        pdf.close();
        
        // Excel-specific features
        System.out.println("\nExcel Document Features:");
        ExcelDocument excel = (ExcelDocument) excelFactory.createDocument();
        excel.open();
        excel.addSheet("Sales Data");
        excel.setCellValue("A1", "Revenue");
        excel.setCellValue("B1", "1000");
        excel.addFormula("C1", "=SUM(B1:B10)");
        excel.save();
        excel.close();
        
        System.out.println("\n================================================");
        System.out.println("ALL TESTS COMPLETED SUCCESSFULLY");
        System.out.println("================================================");
    }
    
    /*
     * Helper method to create documents based on type string.
     * This demonstrates how Factory Method enables dynamic object creation.
     * @param type The type of document to create
     */
    private static void createDocumentByType(String type) {
        DocumentFactory factory;
        
        switch (type.toLowerCase()) {
            case "word":
                factory = new WordDocumentFactory();
                break;
            case "pdf":
                factory = new PdfDocumentFactory();
                break;
            case "excel":
                factory = new ExcelDocumentFactory();
                break;
            default:
                System.out.println("Unknown document type: " + type);
                return;
        }
        
        Document doc = factory.createDocument();
        System.out.println("Created: " + doc.getType());
    }
}
