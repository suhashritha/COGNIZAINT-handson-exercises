/*
 * ExcelDocument - Concrete implementation of Document for Excel files.
 * This is a Concrete Product in the Factory Method Pattern.
 */
public class ExcelDocument implements Document {
    
    private String fileName;
    private int sheetCount;
    
    /*
     * Constructor for ExcelDocument.
     */
    public ExcelDocument() {
        this.fileName = "Untitled.xlsx";
        this.sheetCount = 1; // Default sheet
    }
    
    @Override
    public void open() {
        System.out.println("Opening Excel Document: " + fileName);
        System.out.println("  - Loading Microsoft Excel format (.xlsx)");
        System.out.println("  - Initializing spreadsheet engine");
    }
    
    @Override
    public void save() {
        System.out.println("Saving Excel Document: " + fileName);
        System.out.println("  - Calculating all formulas");
        System.out.println("  - Writing to .xlsx format");
    }
    
    @Override
    public void close() {
        System.out.println("Closing Excel Document: " + fileName);
        System.out.println("  - Releasing spreadsheet resources");
    }
    
    @Override
    public String getType() {
        return "Excel Document (.xlsx)";
    }
    
    /*
     * Excel-specific method to add a sheet.
     * @param sheetName The name of the new sheet
     */
    public void addSheet(String sheetName) {
        sheetCount++;
        System.out.println("Added sheet '" + sheetName + "'. Total sheets: " + sheetCount);
    }
    
    /*
     * Excel-specific method to set cell value.
     * @param cell The cell reference (e.g., "A1")
     * @param value The value to set
     */
    public void setCellValue(String cell, String value) {
        System.out.println("Setting cell " + cell + " = " + value);
    }
    
    /*
     * Excel-specific method to add formula.
     * @param cell The cell reference
     * @param formula The formula (e.g., "=SUM(A1:A10)")
     */
    public void addFormula(String cell, String formula) {
        System.out.println("Adding formula to " + cell + ": " + formula);
    }
}
