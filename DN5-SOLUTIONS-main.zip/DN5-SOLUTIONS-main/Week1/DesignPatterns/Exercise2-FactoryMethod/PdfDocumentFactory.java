/*
 * PdfDocumentFactory - Concrete Factory for creating PDF documents.
 * This is a Concrete Creator in the Factory Method Pattern.
 * It implements the factory method to create PdfDocument instances.
 */
public class PdfDocumentFactory extends DocumentFactory {
    
    /*
     * Factory method implementation for creating PDF documents.
     * @return A new PdfDocument instance
     */
    @Override
    public Document createDocument() {
        System.out.println("PdfDocumentFactory: Creating new PDF Document...");
        return new PdfDocument();
    }
}
