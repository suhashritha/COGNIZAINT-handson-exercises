package com.library.service;

import com.library.model.Book;
import com.library.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/*
 * BookService with Constructor Injection.
 * EXERCISE 7: IMPLEMENTING CONSTRUCTOR INJECTION
 * ===============================================
 * Constructor Injection:
 * - Dependency is injected through constructor
 * - Ensures mandatory dependencies are provided
 * - Object is fully initialized after construction
 * - Dependencies are immutable (final fields)
 * - Preferred approach for required dependencies
 * XML Configuration:
 * <constructor-arg ref="bookRepository"/>
 * Benefits of Constructor Injection:
 * 1. Immutability - dependencies can be final
 * 2. Fail-fast - missing dependencies cause early errors
 * 3. Testability - easy to inject mocks
 * 4. Thread-safe - no synchronization needed
 */
@Service("bookServiceConstructor")
public class BookServiceConstructor {
    
    // Dependency - final for immutability
    private final BookRepository bookRepository;
    
    /*
     * Constructor for dependency injection.
     * Spring will call this constructor with BookRepository bean.
     * @param bookRepository The repository to inject
     */
    public BookServiceConstructor(BookRepository bookRepository) {
        System.out.println("BookServiceConstructor: Constructor called - Constructor Injection");
        this.bookRepository = bookRepository;
    }
    
    /*
     * Get all books from the library.
     * @return List of all books
     */
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }
    
    /*
     * Find a book by ISBN.
     * @param isbn ISBN to search for
     * @return Optional containing the book
     */
    public Optional<Book> findBook(String isbn) {
        return bookRepository.findByIsbn(isbn);
    }
    
    /*
     * Find books by author name.
     * @param author Author name
     * @return List of books by the author
     */
    public List<Book> findBooksByAuthor(String author) {
        return bookRepository.findByAuthor(author);
    }
    
    /*
     * Add a new book to the library.
     * @param book Book to add
     * @return The added book
     */
    public Book addBook(Book book) {
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            throw new IllegalArgumentException("Book already exists: " + book.getIsbn());
        }
        return bookRepository.addBook(book);
    }
    
    /*
     * Borrow a book from the library.
     * @param isbn ISBN of the book to borrow
     * @return true if successfully borrowed
     */
    public boolean borrowBook(String isbn) {
        Optional<Book> bookOpt = bookRepository.findByIsbn(isbn);
        if (bookOpt.isPresent() && bookOpt.get().isAvailable()) {
            Book book = bookOpt.get();
            book.setAvailable(false);
            bookRepository.updateBook(book);
            System.out.println("Book borrowed: " + book.getTitle());
            return true;
        }
        System.out.println("Book not available for borrowing: " + isbn);
        return false;
    }
    
    /*
     * Return a borrowed book.
     * @param isbn ISBN of the book to return
     * @return true if successfully returned
     */
    public boolean returnBook(String isbn) {
        Optional<Book> bookOpt = bookRepository.findByIsbn(isbn);
        if (bookOpt.isPresent() && !bookOpt.get().isAvailable()) {
            Book book = bookOpt.get();
            book.setAvailable(true);
            bookRepository.updateBook(book);
            System.out.println("Book returned: " + book.getTitle());
            return true;
        }
        System.out.println("Book was not borrowed: " + isbn);
        return false;
    }
    
    /*
     * Delete a book from the library.
     * @param isbn ISBN of the book to delete
     */
    public void deleteBook(String isbn) {
        if (!bookRepository.existsByIsbn(isbn)) {
            throw new IllegalArgumentException("Book not found: " + isbn);
        }
        bookRepository.deleteBook(isbn);
        System.out.println("Book deleted: " + isbn);
    }
    
    /*
     * Get count of all books.
     * @return Number of books
     */
    public long getBookCount() {
        return bookRepository.count();
    }
    
    /*
     * Get all available books.
     * @return List of available books
     */
    public List<Book> getAvailableBooks() {
        return bookRepository.findAvailable();
    }
    
    /*
     * Search books by title keyword.
     * @param keyword Keyword to search
     * @return List of matching books
     */
    public List<Book> searchByTitle(String keyword) {
        return bookRepository.findAll().stream()
                .filter(book -> book.getTitle().toLowerCase().contains(keyword.toLowerCase()))
                .toList();
    }
}
