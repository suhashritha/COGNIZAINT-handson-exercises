package com.library.repository;

import com.library.model.Book;
import org.springframework.stereotype.Repository;

import java.util.*;

/*
 * BookRepository - Data Access Layer for Book entities.
 * EXERCISE 1 & 6: Spring Repository Configuration
 * ================================================
 * The @Repository annotation:
 * - Marks this class as a Spring-managed bean
 * - Indicates this is a data access component
 * - Enables exception translation for data access exceptions
 */
@Repository
public class BookRepository {
    
    // In-memory storage (simulating database)
    private final Map<String, Book> books = new HashMap<>();
    
    // Constructor
    public BookRepository() {
        System.out.println("BookRepository: Constructor called - Bean created");
        initializeSampleData();
    }
    
    /*
     * Initialize with sample data.
     */
    private void initializeSampleData() {
        addBook(new Book("978-0-13-468599-1", "Effective Java", "Joshua Bloch", 2018));
        addBook(new Book("978-0-596-51774-8", "Java Concurrency in Practice", "Brian Goetz", 2006));
        addBook(new Book("978-1-61729-439-4", "Spring in Action", "Craig Walls", 2018));
        addBook(new Book("978-0-13-235088-4", "Clean Code", "Robert C. Martin", 2008));
    }
    
    /*
     * Find a book by ISBN.
     * @param isbn The ISBN to search for
     * @return Optional containing the book if found
     */
    public Optional<Book> findByIsbn(String isbn) {
        System.out.println("BookRepository: findByIsbn(" + isbn + ")");
        return Optional.ofNullable(books.get(isbn));
    }
    
    /*
     * Find all books.
     * @return List of all books
     */
    public List<Book> findAll() {
        System.out.println("BookRepository: findAll() - returning " + books.size() + " books");
        return new ArrayList<>(books.values());
    }
    
    /*
     * Find books by author.
     * @param author Author name
     * @return List of books by the author
     */
    public List<Book> findByAuthor(String author) {
        System.out.println("BookRepository: findByAuthor(" + author + ")");
        return books.values().stream()
                .filter(book -> book.getAuthor().toLowerCase().contains(author.toLowerCase()))
                .toList();
    }
    
    /*
     * Find available books.
     * @return List of available books
     */
    public List<Book> findAvailable() {
        System.out.println("BookRepository: findAvailable()");
        return books.values().stream()
                .filter(Book::isAvailable)
                .toList();
    }
    
    /*
     * Add a new book.
     * @param book Book to add
     * @return The added book
     */
    public Book addBook(Book book) {
        System.out.println("BookRepository: addBook(" + book.getTitle() + ")");
        books.put(book.getIsbn(), book);
        return book;
    }
    
    /*
     * Update an existing book.
     * @param book Book to update
     * @return The updated book
     */
    public Book updateBook(Book book) {
        System.out.println("BookRepository: updateBook(" + book.getIsbn() + ")");
        if (!books.containsKey(book.getIsbn())) {
            throw new IllegalArgumentException("Book not found: " + book.getIsbn());
        }
        books.put(book.getIsbn(), book);
        return book;
    }
    
    /*
     * Delete a book by ISBN.
     * @param isbn ISBN of book to delete
     */
    public void deleteBook(String isbn) {
        System.out.println("BookRepository: deleteBook(" + isbn + ")");
        books.remove(isbn);
    }
    
    /*
     * Check if a book exists.
     * @param isbn ISBN to check
     * @return true if book exists
     */
    public boolean existsByIsbn(String isbn) {
        return books.containsKey(isbn);
    }
    
    /*
     * Count total books.
     * @return Number of books
     */
    public long count() {
        return books.size();
    }
}
