package com.library.service;

import com.library.model.Book;
import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/*
 * LibraryService - Demonstrates combined injection approaches.
 * EXERCISE 7: CONSTRUCTOR AND SETTER INJECTION COMBINED
 * ======================================================
 * This class shows:
 * - Constructor injection for required dependencies
 * - Setter injection for optional properties
 * - Field injection with @Autowired
 */
@Service
public class LibraryService {
    
    // Required dependency - constructor injection
    private final BookRepository bookRepository;
    
    // Optional property - setter injection
    private String serviceName;
    
    /*
     * Constructor injection for required dependency.
     * @param bookRepository Required repository
     */
    @Autowired
    public LibraryService(BookRepository bookRepository) {
        System.out.println("LibraryService: Constructor called");
        this.bookRepository = bookRepository;
    }
    
    /*
     * Setter injection for optional property.
     * @param serviceName Name of the library
     */
    public void setServiceName(String serviceName) {
        System.out.println("LibraryService: setServiceName(" + serviceName + ")");
        this.serviceName = serviceName;
    }
    
    /*
     * Get library information.
     * @return Library info string
     */
    public String getLibraryInfo() {
        long bookCount = bookRepository.count();
        return String.format("Library: %s | Total Books: %d", 
            serviceName != null ? serviceName : "Unnamed Library", 
            bookCount);
    }
    
    /*
     * Get all books in the library.
     * @return List of all books
     */
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }
    
    /*
     * Get library statistics.
     * @return Statistics string
     */
    public String getStatistics() {
        List<Book> allBooks = bookRepository.findAll();
        long available = allBooks.stream().filter(Book::isAvailable).count();
        long borrowed = allBooks.size() - available;
        
        return String.format(
            "=== %s Statistics ===\n" +
            "Total Books: %d\n" +
            "Available: %d\n" +
            "Borrowed: %d",
            serviceName != null ? serviceName : "Library",
            allBooks.size(), available, borrowed
        );
    }
    
    /*
     * Print library catalog.
     */
    public void printCatalog() {
        System.out.println("\n=== " + (serviceName != null ? serviceName : "Library") + " Catalog ===");
        System.out.println("-".repeat(60));
        System.out.printf("%-15s %-25s %-15s %s%n", "ISBN", "Title", "Author", "Available");
        System.out.println("-".repeat(60));
        
        for (Book book : bookRepository.findAll()) {
            System.out.printf("%-15s %-25s %-15s %s%n",
                truncate(book.getIsbn(), 15),
                truncate(book.getTitle(), 25),
                truncate(book.getAuthor(), 15),
                book.isAvailable() ? "Yes" : "No"
            );
        }
        System.out.println("-".repeat(60));
    }
    
    private String truncate(String str, int maxLength) {
        if (str == null) return "";
        return str.length() <= maxLength ? str : str.substring(0, maxLength - 3) + "...";
    }
}
