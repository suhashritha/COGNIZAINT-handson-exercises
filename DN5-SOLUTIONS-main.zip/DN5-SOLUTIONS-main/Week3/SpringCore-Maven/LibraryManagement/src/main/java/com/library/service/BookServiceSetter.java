package com.library.service;

import com.library.model.Book;
import com.library.repository.BookRepository;

import java.util.List;
import java.util.Optional;

/*
 * BookService with Setter Injection.
 * EXERCISE 2 & 7: IMPLEMENTING SETTER INJECTION
 * ==============================================
 * Setter Injection:
 * - Dependency is injected through setter methods
 * - Allows optional dependencies
 * - Can be re-injected (mutable)
 * - Good for optional or changeable dependencies
 * XML Configuration:
 * <property name="bookRepository" ref="bookRepository"/>
 */
public class BookServiceSetter {
    
    // Dependency - will be injected via setter
    private BookRepository bookRepository;
    
    // Default constructor
    public BookServiceSetter() {
        System.out.println("BookServiceSetter: Default constructor called");
    }
    
    /*
     * Setter method for dependency injection.
     * Spring will call this method to inject BookRepository.
     * @param bookRepository The repository to inject
     */
    public void setBookRepository(BookRepository bookRepository) {
        System.out.println("BookServiceSetter: setBookRepository() called - Setter Injection");
        this.bookRepository = bookRepository;
    }
    
    /*
     * Get all books from the library.
     * @return List of all books
     */
    public List<Book> getAllBooks() {
        checkDependency();
        return bookRepository.findAll();
    }
    
    /*
     * Find a book by ISBN.
     * @param isbn ISBN to search for
     * @return Optional containing the book
     */
    public Optional<Book> findBook(String isbn) {
        checkDependency();
        return bookRepository.findByIsbn(isbn);
    }
    
    /*
     * Find books by author name.
     * @param author Author name
     * @return List of books by the author
     */
    public List<Book> findBooksByAuthor(String author) {
        checkDependency();
        return bookRepository.findByAuthor(author);
    }
    
    /*
     * Add a new book to the library.
     * @param book Book to add
     * @return The added book
     */
    public Book addBook(Book book) {
        checkDependency();
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            throw new IllegalArgumentException("Book already exists: " + book.getIsbn());
        }
        return bookRepository.addBook(book);
    }
    
    /*
     * Borrow a book from the library.
     * @param isbn ISBN of the book to borrow
     * @return true if successfully borrowed
     */
    public boolean borrowBook(String isbn) {
        checkDependency();
        Optional<Book> bookOpt = bookRepository.findByIsbn(isbn);
        if (bookOpt.isPresent() && bookOpt.get().isAvailable()) {
            Book book = bookOpt.get();
            book.setAvailable(false);
            bookRepository.updateBook(book);
            System.out.println("Book borrowed: " + book.getTitle());
            return true;
        }
        return false;
    }
    
    /*
     * Return a borrowed book.
     * @param isbn ISBN of the book to return
     * @return true if successfully returned
     */
    public boolean returnBook(String isbn) {
        checkDependency();
        Optional<Book> bookOpt = bookRepository.findByIsbn(isbn);
        if (bookOpt.isPresent() && !bookOpt.get().isAvailable()) {
            Book book = bookOpt.get();
            book.setAvailable(true);
            bookRepository.updateBook(book);
            System.out.println("Book returned: " + book.getTitle());
            return true;
        }
        return false;
    }
    
    /*
     * Get count of all books.
     * @return Number of books
     */
    public long getBookCount() {
        checkDependency();
        return bookRepository.count();
    }
    
    /*
     * Get all available books.
     * @return List of available books
     */
    public List<Book> getAvailableBooks() {
        checkDependency();
        return bookRepository.findAvailable();
    }
    
    /*
     * Check if dependency is injected.
     */
    private void checkDependency() {
        if (bookRepository == null) {
            throw new IllegalStateException("BookRepository not injected! " +
                "Please configure setter injection properly.");
        }
    }
}
