package com.library.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

/*
 * LoggingAspect - Cross-cutting Logging Concern.
 * EXERCISE 3 & 8: IMPLEMENTING AOP WITH SPRING
 * =============================================
 * AOP Terminology:
 * - Aspect: Cross-cutting concern module (this class)
 * - Join Point: Point in program execution (method call)
 * - Advice: Action taken at join point (before, after, around)
 * - Pointcut: Predicate matching join points
 * - Weaving: Linking aspects with application code
 * Advice Types:
 * - @Before: Execute before method
 * - @After: Execute after method (always)
 * - @AfterReturning: Execute after successful return
 * - @AfterThrowing: Execute after exception
 * - @Around: Execute before and after (most powerful)
 */
@Aspect
@Component
public class LoggingAspect {
    
    /*
     * Pointcut for all methods in service package.
     */
    @Pointcut("execution(* com.library.service.*.*(..))")
    public void serviceMethods() {}
    
    /*
     * Pointcut for all methods in repository package.
     */
    @Pointcut("execution(* com.library.repository.*.*(..))")
    public void repositoryMethods() {}
    
    /*
     * Before Advice - Executes before method execution.
     * @param joinPoint Join point containing method info
     */
    @Before("serviceMethods()")
    public void logBeforeService(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        Object[] args = joinPoint.getArgs();
        
        System.out.println("[AOP-BEFORE] " + className + "." + methodName + 
            "() called with " + args.length + " argument(s)");
    }
    
    /*
     * After Advice - Executes after method execution (always).
     * @param joinPoint Join point containing method info
     */
    @After("serviceMethods()")
    public void logAfterService(JoinPoint joinPoint) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        System.out.println("[AOP-AFTER] " + className + "." + methodName + "() completed");
    }
    
    /*
     * AfterReturning Advice - Executes after successful return.
     * @param joinPoint Join point containing method info
     * @param result The returned value
     */
    @AfterReturning(pointcut = "serviceMethods()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        String methodName = joinPoint.getSignature().getName();
        
        if (result != null) {
            System.out.println("[AOP-RETURN] " + methodName + "() returned: " + 
                truncateResult(result.toString()));
        }
    }
    
    /*
     * AfterThrowing Advice - Executes after exception.
     * @param joinPoint Join point containing method info
     * @param exception The thrown exception
     */
    @AfterThrowing(pointcut = "serviceMethods()", throwing = "exception")
    public void logAfterThrowing(JoinPoint joinPoint, Exception exception) {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        System.out.println("[AOP-ERROR] " + className + "." + methodName + 
            "() threw exception: " + exception.getMessage());
    }
    
    /*
     * Around Advice - Executes before and after method.
     * Used for measuring execution time.
     * @param joinPoint Proceeding join point
     * @return The method's return value
     * @throws Throwable If method throws exception
     */
    @Around("repositoryMethods()")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        // Record start time
        long startTime = System.currentTimeMillis();
        
        System.out.println("[AOP-AROUND] Starting: " + className + "." + methodName + "()");
        
        try {
            // Proceed with method execution
            Object result = joinPoint.proceed();
            
            // Record end time
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            
            System.out.println("[AOP-AROUND] Completed: " + className + "." + methodName + 
                "() in " + executionTime + " ms");
            
            return result;
            
        } catch (Throwable throwable) {
            long endTime = System.currentTimeMillis();
            System.out.println("[AOP-AROUND] Failed: " + className + "." + methodName + 
                "() after " + (endTime - startTime) + " ms - " + throwable.getMessage());
            throw throwable;
        }
    }
    
    /*
     * Truncate long results for logging.
     */
    private String truncateResult(String result) {
        int maxLength = 100;
        if (result.length() <= maxLength) {
            return result;
        }
        return result.substring(0, maxLength) + "...";
    }
}
