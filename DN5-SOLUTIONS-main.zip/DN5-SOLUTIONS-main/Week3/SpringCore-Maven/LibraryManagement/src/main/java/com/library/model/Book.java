package com.library.model;

/*
 * Book entity class representing a library book.
 */
public class Book {
    
    private String isbn;
    private String title;
    private String author;
    private int year;
    private boolean available;
    
    // Default constructor (required for Spring)
    public Book() {
        this.available = true;
    }
    
    // Constructor with required fields
    public Book(String isbn, String title, String author) {
        this();
        this.isbn = isbn;
        this.title = title;
        this.author = author;
    }
    
    // Full constructor
    public Book(String isbn, String title, String author, int year) {
        this(isbn, title, author);
        this.year = year;
    }
    
    // Getters and Setters
    public String getIsbn() {
        return isbn;
    }
    
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public boolean isAvailable() {
        return available;
    }
    
    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    @Override
    public String toString() {
        return "Book{" +
                "isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", year=" + year +
                ", available=" + available +
                '}';
    }
}
