package com.library;

import com.library.model.Book;
import com.library.repository.BookRepository;
import com.library.service.BookServiceConstructor;
import com.library.service.BookServiceSetter;
import com.library.service.LibraryService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Optional;

/*
 * Library Management Application - Main Entry Point.
 * EXERCISE 1: CONFIGURING A BASIC SPRING APPLICATION
 * ===================================================
 * This application demonstrates:
 * - Loading Spring Application Context from XML
 * - Getting beans from the container
 * - Dependency Injection (both setter and constructor)
 * - AOP (Aspect Oriented Programming)
 */
public class LibraryManagementApplication {
    
    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("LIBRARY MANAGEMENT SYSTEM");
        System.out.println("Spring Core & Maven Exercises - Week 3");
        System.out.println("================================================\n");
        
        // Load Spring Application Context from XML configuration
        System.out.println("Loading Spring Application Context...\n");
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        
        System.out.println("\n================================================");
        System.out.println("SPRING CONTEXT LOADED SUCCESSFULLY");
        System.out.println("================================================\n");
        
        // ===============================================
        // TEST 1: Setter Injection
        // ===============================================
        testSetterInjection(context);
        
        // ===============================================
        // TEST 2: Constructor Injection
        // ===============================================
        testConstructorInjection(context);
        
        // ===============================================
        // TEST 3: Library Service (Combined Injection)
        // ===============================================
        testLibraryService(context);
        
        // ===============================================
        // TEST 4: Bean Scopes
        // ===============================================
        testBeanScopes(context);
        
        // Close the context
        ((ClassPathXmlApplicationContext) context).close();
        
        System.out.println("\n================================================");
        System.out.println("APPLICATION COMPLETED");
        System.out.println("================================================");
    }
    
    /*
     * Test setter injection with BookServiceSetter.
     */
    private static void testSetterInjection(ApplicationContext context) {
        System.out.println("--- TEST 1: SETTER INJECTION ---\n");
        
        // Get bean configured with setter injection
        BookServiceSetter service = context.getBean("bookServiceSetter", BookServiceSetter.class);
        
        System.out.println("\nUsing BookServiceSetter (Setter Injection):");
        System.out.println("Total books: " + service.getBookCount());
        
        // Find a book
        Optional<Book> book = service.findBook("978-0-13-468599-1");
        book.ifPresent(b -> System.out.println("Found book: " + b.getTitle()));
        
        // Find by author
        List<Book> martinBooks = service.findBooksByAuthor("Martin");
        System.out.println("Books by Martin: " + martinBooks.size());
        
        System.out.println();
    }
    
    /*
     * Test constructor injection with BookServiceConstructor.
     */
    private static void testConstructorInjection(ApplicationContext context) {
        System.out.println("--- TEST 2: CONSTRUCTOR INJECTION ---\n");
        
        // Get bean configured with constructor injection
        BookServiceConstructor service = context.getBean("bookServiceConstructor", BookServiceConstructor.class);
        
        System.out.println("\nUsing BookServiceConstructor (Constructor Injection):");
        System.out.println("Total books: " + service.getBookCount());
        
        // Get all books
        List<Book> allBooks = service.getAllBooks();
        System.out.println("All books:");
        for (Book book : allBooks) {
            System.out.println("  - " + book.getTitle() + " by " + book.getAuthor());
        }
        
        // Add a new book
        try {
            Book newBook = new Book("978-1-491-95035-4", "Java: The Complete Reference", "Herbert Schildt", 2017);
            service.addBook(newBook);
            System.out.println("Added new book: " + newBook.getTitle());
        } catch (Exception e) {
            System.out.println("Could not add book: " + e.getMessage());
        }
        
        // Borrow and return a book
        System.out.println("\nBorrowing 'Effective Java'...");
        boolean borrowed = service.borrowBook("978-0-13-468599-1");
        System.out.println("Borrow status: " + (borrowed ? "Success" : "Failed"));
        
        System.out.println("Returning 'Effective Java'...");
        boolean returned = service.returnBook("978-0-13-468599-1");
        System.out.println("Return status: " + (returned ? "Success" : "Failed"));
        
        System.out.println();
    }
    
    /*
     * Test LibraryService with combined injection.
     */
    private static void testLibraryService(ApplicationContext context) {
        System.out.println("--- TEST 3: LIBRARY SERVICE (COMBINED INJECTION) ---\n");
        
        LibraryService libraryService = context.getBean("libraryService", LibraryService.class);
        
        // Print library info
        System.out.println(libraryService.getLibraryInfo());
        
        // Print statistics
        System.out.println(libraryService.getStatistics());
        
        // Print catalog
        libraryService.printCatalog();
        
        System.out.println();
    }
    
    /*
     * Test singleton and prototype bean scopes.
     */
    private static void testBeanScopes(ApplicationContext context) {
        System.out.println("--- TEST 4: BEAN SCOPES ---\n");
        
        // Singleton scope - same instance
        Book singleton1 = context.getBean("singletonBean", Book.class);
        Book singleton2 = context.getBean("singletonBean", Book.class);
        
        System.out.println("Singleton Scope Test:");
        System.out.println("  singleton1 == singleton2: " + (singleton1 == singleton2));
        System.out.println("  Same instance: " + (singleton1.hashCode() == singleton2.hashCode()));
        
        // Prototype scope - different instances
        Book prototype1 = context.getBean("prototypeBean", Book.class);
        Book prototype2 = context.getBean("prototypeBean", Book.class);
        
        System.out.println("\nPrototype Scope Test:");
        System.out.println("  prototype1 == prototype2: " + (prototype1 == prototype2));
        System.out.println("  Same instance: " + (prototype1.hashCode() == prototype2.hashCode()));
        
        System.out.println();
    }
}
