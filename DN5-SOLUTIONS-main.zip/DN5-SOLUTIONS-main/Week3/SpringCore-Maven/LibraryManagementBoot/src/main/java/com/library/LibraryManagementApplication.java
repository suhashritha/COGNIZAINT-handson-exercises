package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * LibraryManagementApplication - Spring Boot Main Application.
 * EXERCISE 9: CREATING A SPRING BOOT APPLICATION
 * ===============================================
 * @SpringBootApplication combines:
 * - @Configuration: Marks as configuration class
 * - @EnableAutoConfiguration: Auto-configure based on classpath
 * - @ComponentScan: Scan for components in package
 * To Run:
 * 1. mvn spring-boot:run
 * 2. Or run this main class directly
 * Access Points:
 * - API: http://localhost:8080/api/books
 * - H2 Console: http://localhost:8080/h2-console
 * - Actuator Health: http://localhost:8080/actuator/health
 */
@SpringBootApplication
public class LibraryManagementApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);
        
        System.out.println("\n================================================");
        System.out.println("LIBRARY MANAGEMENT SYSTEM - SPRING BOOT");
        System.out.println("================================================");
        System.out.println("Application started successfully!");
        System.out.println("");
        System.out.println("API Base URL: http://localhost:8080/api/books");
        System.out.println("H2 Console: http://localhost:8080/h2-console");
        System.out.println("Health Check: http://localhost:8080/actuator/health");
        System.out.println("");
        System.out.println("REST Endpoints:");
        System.out.println("  GET    /api/books           - Get all books");
        System.out.println("  GET    /api/books/{id}      - Get book by ID");
        System.out.println("  POST   /api/books           - Create book");
        System.out.println("  PUT    /api/books/{id}      - Update book");
        System.out.println("  DELETE /api/books/{id}      - Delete book");
        System.out.println("  GET    /api/books/search?q= - Search books");
        System.out.println("  GET    /api/books/available - Get available books");
        System.out.println("  PATCH  /api/books/{id}/borrow - Borrow book");
        System.out.println("  PATCH  /api/books/{id}/return - Return book");
        System.out.println("================================================\n");
    }
}
