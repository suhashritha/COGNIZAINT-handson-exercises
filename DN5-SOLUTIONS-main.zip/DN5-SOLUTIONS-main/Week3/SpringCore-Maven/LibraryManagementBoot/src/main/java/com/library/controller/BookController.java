package com.library.controller;

import com.library.entity.Book;
import com.library.repository.BookRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * BookController - REST Controller for Book operations.
 * EXERCISE 9: SPRING BOOT - REST CONTROLLER
 * ==========================================
 * REST API Endpoints:
 * - GET    /api/books        - Get all books
 * - GET    /api/books/{id}   - Get book by ID
 * - POST   /api/books        - Create new book
 * - PUT    /api/books/{id}   - Update book
 * - DELETE /api/books/{id}   - Delete book
 * - GET    /api/books/search - Search books
 * HTTP Status Codes:
 * - 200 OK: Successful GET/PUT
 * - 201 Created: Successful POST
 * - 204 No Content: Successful DELETE
 * - 400 Bad Request: Validation error
 * - 404 Not Found: Resource not found
 * - 409 Conflict: Duplicate resource
 */
@RestController
@RequestMapping("/api/books")
public class BookController {
    
    private final BookRepository bookRepository;
    
    @Autowired
    public BookController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    
    /*
     * GET /api/books - Get all books.
     * @return List of all books
     */
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        return ResponseEntity.ok(books);
    }
    
    /*
     * GET /api/books/{id} - Get book by ID.
     * @param id Book ID
     * @return Book if found, 404 otherwise
     */
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        return bookRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * GET /api/books/isbn/{isbn} - Get book by ISBN.
     * @param isbn Book ISBN
     * @return Book if found, 404 otherwise
     */
    @GetMapping("/isbn/{isbn}")
    public ResponseEntity<Book> getBookByIsbn(@PathVariable String isbn) {
        return bookRepository.findByIsbn(isbn)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * POST /api/books - Create a new book.
     * @param book Book to create
     * @return Created book with 201 status
     */
    @PostMapping
    public ResponseEntity<?> createBook(@Valid @RequestBody Book book) {
        // Check for duplicate ISBN
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Book with ISBN already exists: " + book.getIsbn());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(error);
        }
        
        Book savedBook = bookRepository.save(book);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
    }
    
    /*
     * PUT /api/books/{id} - Update an existing book.
     * @param id Book ID
     * @param bookDetails Updated book details
     * @return Updated book or 404
     */
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(
            @PathVariable Long id, 
            @Valid @RequestBody Book bookDetails) {
        
        return bookRepository.findById(id)
                .map(existingBook -> {
                    existingBook.setTitle(bookDetails.getTitle());
                    existingBook.setAuthor(bookDetails.getAuthor());
                    existingBook.setPublicationYear(bookDetails.getPublicationYear());
                    existingBook.setGenre(bookDetails.getGenre());
                    // Don't update ISBN to maintain data integrity
                    
                    Book updatedBook = bookRepository.save(existingBook);
                    return ResponseEntity.ok(updatedBook);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * DELETE /api/books/{id} - Delete a book.
     * @param id Book ID
     * @return 204 No Content or 404
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        return bookRepository.findById(id)
                .map(book -> {
                    bookRepository.delete(book);
                    return ResponseEntity.noContent().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * GET /api/books/search - Search books.
     * @param q Search query
     * @return List of matching books
     */
    @GetMapping("/search")
    public ResponseEntity<List<Book>> searchBooks(@RequestParam String q) {
        List<Book> books = bookRepository.searchBooks(q);
        return ResponseEntity.ok(books);
    }
    
    /*
     * GET /api/books/available - Get available books.
     * @return List of available books
     */
    @GetMapping("/available")
    public ResponseEntity<List<Book>> getAvailableBooks() {
        List<Book> books = bookRepository.findByAvailableTrue();
        return ResponseEntity.ok(books);
    }
    
    /*
     * GET /api/books/author/{author} - Get books by author.
     * @param author Author name
     * @return List of books by author
     */
    @GetMapping("/author/{author}")
    public ResponseEntity<List<Book>> getBooksByAuthor(@PathVariable String author) {
        List<Book> books = bookRepository.findByAuthorContainingIgnoreCase(author);
        return ResponseEntity.ok(books);
    }
    
    /*
     * GET /api/books/genre/{genre} - Get books by genre.
     * @param genre Genre name
     * @return List of books in genre
     */
    @GetMapping("/genre/{genre}")
    public ResponseEntity<List<Book>> getBooksByGenre(@PathVariable String genre) {
        List<Book> books = bookRepository.findByGenreIgnoreCase(genre);
        return ResponseEntity.ok(books);
    }
    
    /*
     * PATCH /api/books/{id}/borrow - Borrow a book.
     * @param id Book ID
     * @return Updated book or error
     */
    @PatchMapping("/{id}/borrow")
    public ResponseEntity<?> borrowBook(@PathVariable Long id) {
        return bookRepository.findById(id)
                .map(book -> {
                    if (!book.isAvailable()) {
                        Map<String, String> error = new HashMap<>();
                        error.put("error", "Book is not available for borrowing");
                        return ResponseEntity.badRequest().body(error);
                    }
                    book.setAvailable(false);
                    Book updatedBook = bookRepository.save(book);
                    return ResponseEntity.ok(updatedBook);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * PATCH /api/books/{id}/return - Return a book.
     * @param id Book ID
     * @return Updated book or error
     */
    @PatchMapping("/{id}/return")
    public ResponseEntity<?> returnBook(@PathVariable Long id) {
        return bookRepository.findById(id)
                .map(book -> {
                    if (book.isAvailable()) {
                        Map<String, String> error = new HashMap<>();
                        error.put("error", "Book was not borrowed");
                        return ResponseEntity.badRequest().body(error);
                    }
                    book.setAvailable(true);
                    Book updatedBook = bookRepository.save(book);
                    return ResponseEntity.ok(updatedBook);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    /*
     * GET /api/books/stats - Get library statistics.
     * @return Statistics map
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalBooks", bookRepository.count());
        stats.put("availableBooks", bookRepository.countByAvailableTrue());
        stats.put("borrowedBooks", bookRepository.count() - bookRepository.countByAvailableTrue());
        stats.put("authors", bookRepository.findAllAuthors());
        return ResponseEntity.ok(stats);
    }
}
