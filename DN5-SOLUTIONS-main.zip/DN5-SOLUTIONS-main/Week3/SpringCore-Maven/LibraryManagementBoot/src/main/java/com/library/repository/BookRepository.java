package com.library.repository;

import com.library.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/*
 * BookRepository - Spring Data JPA Repository.
 * EXERCISE 9: SPRING BOOT - REPOSITORY INTERFACE
 * ===============================================
 * Spring Data JPA Features:
 * - Extends JpaRepository for CRUD operations
 * - Query method naming conventions
 * - Custom @Query annotations
 * - Automatic implementation at runtime
 * Inherited Methods:
 * - save(), findById(), findAll(), deleteById()
 * - count(), existsById(), etc.
 */
@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    
    /*
     * Find book by ISBN.
     * Spring Data JPA creates implementation from method name.
     * @param isbn ISBN to search
     * @return Optional containing book if found
     */
    Optional<Book> findByIsbn(String isbn);
    
    /*
     * Find books by author name (case-insensitive).
     * @param author Author name
     * @return List of books by author
     */
    List<Book> findByAuthorContainingIgnoreCase(String author);
    
    /*
     * Find books by title keyword (case-insensitive).
     * @param keyword Keyword to search
     * @return List of matching books
     */
    List<Book> findByTitleContainingIgnoreCase(String keyword);
    
    /*
     * Find all available books.
     * @return List of available books
     */
    List<Book> findByAvailableTrue();
    
    /*
     * Find all unavailable (borrowed) books.
     * @return List of borrowed books
     */
    List<Book> findByAvailableFalse();
    
    /*
     * Find books by genre.
     * @param genre Genre to search
     * @return List of books in genre
     */
    List<Book> findByGenreIgnoreCase(String genre);
    
    /*
     * Find books by publication year.
     * @param year Publication year
     * @return List of books from that year
     */
    List<Book> findByPublicationYear(Integer year);
    
    /*
     * Find books published after a year.
     * @param year Year threshold
     * @return List of books published after year
     */
    List<Book> findByPublicationYearGreaterThan(Integer year);
    
    /*
     * Check if book exists by ISBN.
     * @param isbn ISBN to check
     * @return true if exists
     */
    boolean existsByIsbn(String isbn);
    
    /*
     * Count available books.
     * @return Number of available books
     */
    long countByAvailableTrue();
    
    /*
     * Custom JPQL query - Search by author or title.
     * @param searchTerm Search term
     * @return List of matching books
     */
    @Query("SELECT b FROM Book b WHERE " +
           "LOWER(b.author) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(b.title) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Book> searchBooks(@Param("searchTerm") String searchTerm);
    
    /*
     * Native SQL query - Get all authors.
     * @return List of unique author names
     */
    @Query(value = "SELECT DISTINCT author FROM books ORDER BY author", nativeQuery = true)
    List<String> findAllAuthors();
}
