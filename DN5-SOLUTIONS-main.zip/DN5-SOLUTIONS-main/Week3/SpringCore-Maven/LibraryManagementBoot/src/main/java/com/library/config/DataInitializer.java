package com.library.config;

import com.library.entity.Book;
import com.library.repository.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*
 * DataInitializer - Populates sample data on startup.
 * CommandLineRunner executes after Spring context is loaded.
 */
@Configuration
public class DataInitializer {
    
    @Bean
    CommandLineRunner initDatabase(BookRepository repository) {
        return args -> {
            System.out.println("Initializing sample book data...");
            
            // Classic Programming Books
            repository.save(new Book(
                "978-0-13-468599-1", 
                "Effective Java", 
                "Joshua Bloch", 
                2018, 
                "Programming"
            ));
            
            repository.save(new Book(
                "978-0-596-51774-8", 
                "Java Concurrency in Practice", 
                "Brian Goetz", 
                2006, 
                "Programming"
            ));
            
            repository.save(new Book(
                "978-0-13-235088-4", 
                "Clean Code", 
                "Robert C. Martin", 
                2008, 
                "Software Engineering"
            ));
            
            repository.save(new Book(
                "978-0-201-63361-0", 
                "Design Patterns", 
                "Gang of Four", 
                1994, 
                "Software Engineering"
            ));
            
            // Spring Books
            repository.save(new Book(
                "978-1-61729-439-4", 
                "Spring in Action", 
                "Craig Walls", 
                2018, 
                "Spring Framework"
            ));
            
            repository.save(new Book(
                "978-1-4842-2790-6", 
                "Pro Spring 5", 
                "Iuliana Cosmina", 
                2017, 
                "Spring Framework"
            ));
            
            // Architecture Books
            repository.save(new Book(
                "978-1-491-95035-4", 
                "Building Microservices", 
                "Sam Newman", 
                2021, 
                "Architecture"
            ));
            
            repository.save(new Book(
                "978-0-321-12521-7", 
                "Domain-Driven Design", 
                "Eric Evans", 
                2003, 
                "Architecture"
            ));
            
            // Database Books
            repository.save(new Book(
                "978-1-449-37320-0", 
                "Learning SQL", 
                "Alan Beaulieu", 
                2020, 
                "Database"
            ));
            
            repository.save(new Book(
                "978-0-13-468856-5", 
                "High Performance MySQL", 
                "Baron Schwartz", 
                2021, 
                "Database"
            ));
            
            System.out.println("Sample data initialized: " + repository.count() + " books");
        };
    }
}
